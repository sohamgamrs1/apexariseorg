'use client';
import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { api } from './api';
import { SHOP } from './data';
import { haptic } from './haptics';
import { sfx } from './sound';

export const istToday = () => new Date(Date.now() + 19_800_000).toISOString().slice(0, 10);

export type Hunter = {
  name: string; avatar_id: string; custom_avatar_url: string | null;
  level: number; xp: number; need: number; points: number; gold: number; streak: number; best_streak: number;
  stat_str: number; stat_int: number; stat_agi: number; stat_vit: number; stat_sen: number; xp_boost_until: string | null;
};
type Toast = { id: number; text: string; tone: 'gain' | 'error' | 'info' };

interface State {
  status: 'loading' | 'ready' | 'unauth' | 'error';
  hunter: Hunter | null;
  owned: Record<string, number>;
  arcs: Record<string, string>; // challenge id -> start date (IST); moves server-side with the Arc screen
  sound: boolean; toasts: Toast[]; onboarded: boolean;
  hydrate: () => Promise<void>;
  buy: (itemId: string) => Promise<void>;
  rename: (name: string) => Promise<void>;
  startArc: (id: string, title: string) => void;
  toggleSound: () => void;
  patchHunter: (p: Partial<Hunter>) => void;
  finishOnboarding: () => void;
  toast: (text: string, tone?: Toast['tone']) => void;
  dismissToast: (id: number) => void;
}

const ERRORS: Record<string, string> = {
  INSUFFICIENT_GOLD: 'Not enough gold', ALREADY_OWNED: 'Already owned', COMING_SOON: 'Coming soon',
  UNAUTHORIZED: 'Session expired. Sign in again.',
};
let tid = 0;

export const useApex = create<State>()(
  persist(
    (set, get) => ({
      status: 'loading', hunter: null, owned: {}, arcs: {}, sound: true, toasts: [], onboarded: false,

      toast: (text, tone = 'info') => {
        const id = ++tid;
        if (get().sound) sfx(tone);
        set((s) => ({ toasts: [...s.toasts, { id, text, tone }] }));
        setTimeout(() => get().dismissToast(id), 2800);
      },
      dismissToast: (id) => set((s) => ({ toasts: s.toasts.filter((t) => t.id !== id) })),
      toggleSound: () => set((s) => ({ sound: !s.sound })),
      patchHunter: (p) => set((s) => ({ hunter: s.hunter && { ...s.hunter, ...p } })),
      finishOnboarding: () => set({ onboarded: true }),

      hydrate: async () => {
        set({ status: 'loading' });
        const r = await api<{ hunter: Hunter; owned: Record<string, number> }>('/api/hunter');
        if (r.status === 401) return set({ status: 'unauth' });
        if (!r.ok) return set({ status: 'error' });
        set({ hunter: r.data.hunter, owned: r.data.owned, status: 'ready' });
      },

      buy: async (itemId) => {
        const { hunter, owned } = get();
        const item = SHOP.find((i) => i.id === itemId);
        if (!hunter || !item) return;
        if (item.soon) return get().toast('Coming soon', 'info');
        if (item.avatarId && owned[itemId]) return get().toast('Already owned', 'error');
        if (hunter.gold < item.cost) { haptic([30, 40, 30]); return get().toast('Not enough gold', 'error'); }

        const prev = { hunter, owned };
        set({ hunter: { ...hunter, gold: hunter.gold - item.cost }, owned: { ...owned, [itemId]: (owned[itemId] ?? 0) + 1 } });
        haptic(20);
        const r = await api<{ gold: number; xp_boost_until: string | null }>('/api/shop/purchase', 'POST', { itemId });
        if (!r.ok) { // roll back the optimistic update
          set(prev);
          return get().toast(ERRORS[r.data.error ?? ''] ?? 'Purchase failed. Try again.', 'error');
        }
        set((s) => ({ hunter: s.hunter && { ...s.hunter, gold: r.data.gold, ...(r.data.xp_boost_until ? { xp_boost_until: r.data.xp_boost_until } : {}) } }));
        get().toast(`${item.name} purchased`, 'gain');
      },

      rename: async (name) => {
        const r = await api<{ name: string }>('/api/hunter/rename', 'POST', { name });
        if (!r.ok) return get().toast(r.data.error === 'NO_NAME_TOKEN' ? 'Requires a Name Token (40G in the Shop)' : 'Could not rename', 'error');
        set((s) => {
          const o = { ...s.owned };
          if ((o.nameToken ?? 0) <= 1) delete o.nameToken; else o.nameToken -= 1;
          return { hunter: s.hunter && { ...s.hunter, name: r.data.name }, owned: o };
        });
        get().toast('Hunter name updated', 'gain');
      },

      startArc: (id, title) => {
        set((s) => ({ arcs: { ...s.arcs, [id]: istToday() } }));
        haptic(20);
        get().toast(`${title} started. Day 1`, 'info');
      },
    }),
    { name: 'apex-ascend-v1', partialize: (s) => ({ arcs: s.arcs, sound: s.sound, onboarded: s.onboarded }) },
  ),
);
