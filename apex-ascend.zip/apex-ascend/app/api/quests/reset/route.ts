import { z } from 'zod';
import { callRpc } from '@/lib/rpc';

export const POST = (req: Request) => callRpc(req, z.object({}), 'reset_daily_quests', (uid) => ({ p_user: uid }));
