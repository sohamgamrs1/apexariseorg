-- Apex Ascend: schema, seeds, RLS, and atomic game-logic RPCs.
create extension if not exists pgcrypto;

create type dungeon_status as enum ('idle','active','completed','failed');
create type coach_role as enum ('user','ai');
create type avatar_tier as enum ('common','rare','epic','legendary','ultimate');

create table avatars (
  id text primary key, name text not null, tier avatar_tier not null,
  price int not null default 0 check (price >= 0), unlock_condition text
);

create table hunters (
  id uuid primary key references auth.users on delete cascade,
  name text not null default 'Hunter',
  avatar_id text not null default 'lion' references avatars(id),
  custom_avatar_url text,
  level int not null default 1 check (level >= 1),
  xp int not null default 0 check (xp >= 0),
  gold int not null default 0 check (gold >= 0),
  streak int not null default 0, best_streak int not null default 0,
  last_active date, created_at timestamptz not null default now()
);

create table challenger_bosses (
  id text primary key, name text not null, emoji text, title text, color text,
  bg text, border text, reward_text text, gold_reward int not null default 0
);
create table boss_challenges (
  id text primary key, boss_id text not null references challenger_bosses(id),
  title text not null, icon text, xp int not null default 50
);
create table weekly_boss_state (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references hunters(id) on delete cascade,
  week_start date not null, hp int not null default 1000, max_hp int not null default 1000,
  is_defeated boolean not null default false, defeated_at timestamptz,
  unique (user_id, week_start)
);
create table daily_boss_limit (
  user_id uuid not null references hunters(id) on delete cascade,
  date date not null, count int not null default 0, primary key (user_id, date)
);
create table shadow_army (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references hunters(id) on delete cascade,
  soldier_index int not null check (soldier_index between 0 and 24),
  unlocked boolean not null default false, unlocked_at timestamptz, habit_name text,
  unique (user_id, soldier_index)
);
create table dungeon_runs (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references hunters(id) on delete cascade,
  start_time timestamptz, end_time timestamptz, duration int not null default 90,
  status dungeon_status not null default 'idle', best_time int
);
create table journal_entries (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references hunters(id) on delete cascade,
  date date not null, win text, learn text, tomorrow text, mood text, streak_snapshot int,
  unique (user_id, date)
);
create table weekly_reviews (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references hunters(id) on delete cascade,
  week_start date not null, content jsonb, created_at timestamptz not null default now()
);
create table coach_messages (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references hunters(id) on delete cascade,
  role coach_role not null, content text not null, created_at timestamptz not null default now()
);
create table gold_shop_items (
  id text primary key, name text not null, icon text, cost int not null check (cost >= 0),
  "desc" text, is_avatar boolean not null default false, avatar_id text references avatars(id)
);
create table user_inventory (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references hunters(id) on delete cascade,
  item_id text not null references gold_shop_items(id), purchased_at timestamptz not null default now(),
  unique (user_id, item_id)
);
create table glory_logs (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references hunters(id) on delete cascade,
  challenge_id text, glory_title text, challenge_title text, icon text, color text,
  xp int not null default 0, gold int not null default 0, date date not null, duration int
);
create index on glory_logs (user_id, date desc);
create index on journal_entries (user_id, date desc);
create index on coach_messages (user_id, created_at);

-- Seeds (avatar prices and challenge text are placeholders; adjust to match the original)
insert into avatars values
 ('lion','Lion','common',0,'Default'),('wolf','Wolf','common',200,null),
 ('monarch','Monarch','rare',300,null),('flame','Flame','rare',400,null),
 ('frost','Frost','rare',400,null),('groom','Groom','epic',500,null),
 ('rose','Rose','epic',600,null),('berserker','Berserker','epic',600,null),
 ('dragon','Dragon','legendary',700,null),('lunar','Lunar','legendary',800,null),
 ('void','Void','ultimate',1000,null),('shadow_monarch','Shadow Monarch','ultimate',1000,null);

insert into challenger_bosses (id,name,emoji,title,color,reward_text,gold_reward) values
 ('iron_titan','Iron Titan','🛡️','Guardian of Strength','#fbbf24','+150 Gold',150),
 ('frost_monarch','Frost Monarch','❄️','Ruler of Stillness','#7dd3fc','+150 Gold',150),
 ('shadow_dragon','Shadow Dragon','🐉','Wyrm of Focus','#a78bfa','+200 Gold',200),
 ('demon_lord','Demon Lord','👹','Tyrant of Temptation','#f87171','+200 Gold',200),
 ('void_walker','Void Walker','🌌','Drifter of the Abyss','#34d399','+250 Gold',250);

insert into boss_challenges (id,boss_id,title,icon,xp) values
 ('it_1','iron_titan','50 Push-ups','💪',50),('it_2','iron_titan','100 Squats','🦵',50),
 ('it_3','iron_titan','2 min Plank','🧱',50),('it_4','iron_titan','Cold Shower','🚿',50),
 ('fm_1','frost_monarch','10 min Meditation','🧘',50),('fm_2','frost_monarch','No Phone 1 hr','📵',50),
 ('fm_3','frost_monarch','Journal Entry','📓',50),('fm_4','frost_monarch','Sleep by 11 PM','😴',50),
 ('sd_1','shadow_dragon','90 min Deep Work','🎯',50),('sd_2','shadow_dragon','Read 20 pages','📖',50),
 ('sd_3','shadow_dragon','Plan Tomorrow','🗓️',50),('sd_4','shadow_dragon','No Social Media','🚫',50),
 ('dl_1','demon_lord','No Sugar Today','🍬',50),('dl_2','demon_lord','No Junk Food','🍔',50),
 ('dl_3','demon_lord','3 L Water','💧',50),('dl_4','demon_lord','Wake at 5 AM','⏰',50),
 ('vw_1','void_walker','5 km Walk','🚶',50),('vw_2','void_walker','Stretch 15 min','🤸',50),
 ('vw_3','void_walker','Gratitude List','🙏',50),('vw_4','void_walker','Digital Sunset','🌇',50);

insert into gold_shop_items (id,name,icon,cost,"desc") values
 ('theme','Theme Unlock','🎨',50,'Unlock a new UI theme'),
 ('extraRandom','Extra Random','🎲',30,'One extra random quest'),
 ('xpBoost','XP Boost','⚡',80,'Bonus XP boost'),
 ('nameToken','Name Token','🏷️',40,'Change your Hunter name');
insert into gold_shop_items (id,name,icon,cost,"desc",is_avatar,avatar_id)
 select 'avatar_'||id, name, '🧑‍🎤', price, tier::text||' avatar', true, id from avatars where price > 0;

-- New auth user -> hunter row
create or replace function handle_new_user() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  insert into hunters (id, name)
  values (new.id, coalesce(new.raw_user_meta_data->>'name', split_part(new.email,'@',1), 'Hunter'))
  on conflict do nothing;
  return new;
end $$;
create trigger on_auth_user_created after insert on auth.users
  for each row execute function handle_new_user();

-- RLS: clients read their own rows; all writes go through the service role / RPCs.
do $$ declare t text; begin
  foreach t in array array['hunters','weekly_boss_state','daily_boss_limit','shadow_army','dungeon_runs',
    'journal_entries','weekly_reviews','coach_messages','user_inventory','glory_logs'] loop
    execute format('alter table %I enable row level security', t);
    execute format('create policy "own rows read" on %I for select using (%s)', t,
      case when t = 'hunters' then 'id = auth.uid()' else 'user_id = auth.uid()' end);
  end loop;
  foreach t in array array['avatars','challenger_bosses','boss_challenges','gold_shop_items'] loop
    execute format('alter table %I enable row level security', t);
    execute format('create policy "public read" on %I for select using (true)', t);
  end loop;
end $$;

create or replace function ist_today() returns date language sql stable as
$$ select (now() at time zone 'Asia/Kolkata')::date $$;

-- Atomic boss defeat: validates all 4 challenges, enforces 1 defeat/day (race-safe), pays out.
create or replace function defeat_boss(p_user uuid, p_boss text, p_done text[])
returns jsonb language plpgsql security definer set search_path = public as $$
declare
  v_boss challenger_bosses%rowtype; v_today date := ist_today();
  v_total int; v_valid int; v_xp int; v_h hunters%rowtype;
begin
  select * into v_boss from challenger_bosses where id = p_boss;
  if not found then raise exception 'UNKNOWN_BOSS'; end if;

  select count(*), coalesce(sum(xp),0) into v_total, v_xp from boss_challenges where boss_id = p_boss;
  select count(distinct c) into v_valid from unnest(p_done) c
    where c in (select id from boss_challenges where boss_id = p_boss);
  if v_valid < v_total then raise exception 'INCOMPLETE'; end if;

  insert into daily_boss_limit (user_id, date, count) values (p_user, v_today, 1)
    on conflict (user_id, date) do nothing;
  if not found then raise exception 'DAILY_LIMIT'; end if;

  update hunters set gold = gold + v_boss.gold_reward, xp = xp + v_xp,
    level = 1 + (xp + v_xp) / 100, last_active = v_today
  where id = p_user returning * into v_h;
  if not found then raise exception 'NO_HUNTER'; end if;

  insert into glory_logs (user_id, challenge_id, glory_title, challenge_title, icon, color, xp, gold, date)
  values (p_user, p_boss, v_boss.title, v_boss.name, v_boss.emoji, v_boss.color, v_xp, v_boss.gold_reward, v_today);

  return jsonb_build_object('defeated', true, 'reward_gold', v_boss.gold_reward, 'reward_xp', v_xp,
    'gold', v_h.gold, 'xp', v_h.xp, 'level', v_h.level);
end $$;

-- Atomic purchase: never lets gold go negative; avatars can only be bought once.
create or replace function purchase_item(p_user uuid, p_item text)
returns jsonb language plpgsql security definer set search_path = public as $$
declare v_item gold_shop_items%rowtype; v_gold int;
begin
  select * into v_item from gold_shop_items where id = p_item;
  if not found then raise exception 'UNKNOWN_ITEM'; end if;
  if v_item.is_avatar and exists (select 1 from user_inventory where user_id = p_user and item_id = p_item)
    then raise exception 'ALREADY_OWNED'; end if;

  update hunters set gold = gold - v_item.cost where id = p_user and gold >= v_item.cost returning gold into v_gold;
  if not found then raise exception 'INSUFFICIENT_GOLD'; end if;

  insert into user_inventory (user_id, item_id) values (p_user, p_item)
    on conflict (user_id, item_id) do nothing;
  return jsonb_build_object('purchased', p_item, 'gold', v_gold);
end $$;

revoke all on function defeat_boss(uuid,text,text[]), purchase_item(uuid,text) from public, anon, authenticated;
grant execute on function defeat_boss(uuid,text,text[]), purchase_item(uuid,text) to service_role;
