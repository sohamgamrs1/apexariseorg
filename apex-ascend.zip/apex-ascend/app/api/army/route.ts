import { z } from 'zod';
import { callRpc } from '@/lib/rpc';

const Input = z.object({});

export const GET = (req: Request) =>
  callRpc(req, Input, 'army_status', (uid) => ({ p_user: uid }));
