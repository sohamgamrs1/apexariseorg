import { NextResponse } from 'next/server';
import { z } from 'zod';
import { createServerClient } from '@/lib/supabase/server';
import { createAdminClient } from '@/lib/supabase/admin';
import { coachReply, type Week } from '@/lib/coach';

const Body = z.object({ content: z.string().trim().min(1).max(500) });

export async function POST(req: Request) {
  const { data: { user } } = await createServerClient().auth.getUser();
  if (!user) return NextResponse.json({ error: 'UNAUTHORIZED' }, { status: 401 });
  const parsed = Body.safeParse(await req.json().catch(() => null));
  if (!parsed.success) return NextResponse.json({ error: 'BAD_REQUEST' }, { status: 400 });

  const admin = createAdminClient();
  const reply = await coachReply(parsed.data.content, {
    streak: async () => (await admin.rpc('journal_history', { p_user: user.id, p_limit: 1 })).data?.current_streak ?? 0,
    week: async () => (await admin.rpc('generate_weekly_review', { p_user: user.id })).data as Week,
  });

  const t = Date.now(); // distinct timestamps keep chat order stable
  const { error } = await admin.from('coach_messages').insert([
    { user_id: user.id, role: 'user', content: parsed.data.content, created_at: new Date(t).toISOString() },
    { user_id: user.id, role: 'ai', content: reply, created_at: new Date(t + 1).toISOString() },
  ]);
  if (error) return NextResponse.json({ error: 'SERVER_ERROR' }, { status: 500 });
  return NextResponse.json({ reply });
}
