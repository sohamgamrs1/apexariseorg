import { NextResponse } from 'next/server';
import { createServerClient } from '@/lib/supabase/server';
import { createAdminClient } from '@/lib/supabase/admin';

export const dynamic = 'force-dynamic';

// Hunter profile + inventory. `streak` is the live streak (0 once a day has been missed), not the stored value.
export async function GET() {
  const { data: { user } } = await createServerClient().auth.getUser();
  if (!user) return NextResponse.json({ error: 'UNAUTHORIZED' }, { status: 401 });

  const db = createAdminClient();
  const [h, inv, j] = await Promise.all([
    db.from('hunters').select('name,avatar_id,custom_avatar_url,level,xp,need,points,gold,streak,best_streak,stat_str,stat_int,stat_agi,stat_vit,stat_sen,xp_boost_until').eq('id', user.id).single(),
    db.from('user_inventory').select('item_id,qty').eq('user_id', user.id),
    db.rpc('journal_history', { p_user: user.id, p_limit: 1 }),
  ]);
  if (h.error) return NextResponse.json({ error: 'NO_HUNTER' }, { status: 404 });

  return NextResponse.json({
    hunter: { ...h.data, streak: j.data?.current_streak ?? 0 },
    owned: Object.fromEntries((inv.data ?? []).map((r) => [r.item_id, r.qty])),
  });
}
