// Minimal service worker: cache-first for static build assets, network-first for pages. API and auth are never cached.
const CACHE = 'apex-v1';
const put = (req, res) => { const copy = res.clone(); caches.open(CACHE).then((c) => c.put(req, copy)); return res; };

self.addEventListener('install', () => self.skipWaiting());
self.addEventListener('activate', (e) =>
  e.waitUntil(caches.keys().then((ks) => Promise.all(ks.filter((k) => k !== CACHE).map((k) => caches.delete(k)))).then(() => self.clients.claim())));

self.addEventListener('fetch', (e) => {
  const { request } = e; const url = new URL(request.url);
  if (request.method !== 'GET' || url.origin !== location.origin || url.pathname.startsWith('/api/') || url.pathname.startsWith('/auth/')) return;
  if (url.pathname.startsWith('/_next/static/')) {
    e.respondWith(caches.match(request).then((hit) => hit || fetch(request).then((res) => put(request, res))));
  } else if (request.mode === 'navigate') {
    e.respondWith(fetch(request).then((res) => put(request, res)).catch(() => caches.match(request).then((hit) => hit || caches.match('/'))));
  }
});
