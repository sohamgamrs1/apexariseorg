export const haptic = (pattern: number | number[] = 12) => {
  try { if (typeof navigator !== 'undefined') navigator.vibrate?.(pattern); } catch { /* unsupported */ }
};
