import type { Config } from 'tailwindcss';

export default {
  content: ['./app/**/*.{ts,tsx}', './components/**/*.{ts,tsx}'],
  theme: {
    extend: {
      fontFamily: {
        heading: ['var(--font-heading)', 'Inter', 'sans-serif'],
        body: ['var(--font-body)'],
        mono: ['var(--font-mono)', 'monospace'],
      },
      colors: { boss: { iron: '#fbbf24', frost: '#7dd3fc', dragon: '#a78bfa', demon: '#f87171', void: '#34d399' } },
    },
  },
  plugins: [],
} satisfies Config;
