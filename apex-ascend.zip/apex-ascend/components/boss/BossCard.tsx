'use client';
import { motion } from 'framer-motion';
import { type Boss, useBoss } from '@/lib/boss-store';

export function BossCard({ boss }: { boss: Boss }) {
  const st = useBoss((s) => s.status)!;
  const done = useBoss((s) => s.done);
  const toggle = useBoss((s) => s.toggle);
  const defeat = useBoss((s) => s.defeat);
  const claiming = useBoss((s) => s.claiming);

  const weekly = boss.is_weekly;
  const total = boss.challenges.length;
  const prog = boss.challenges.filter((c) => done.includes(c.id)).length;
  const claimed = weekly ? st.weekly_defeated : st.claimed_today.includes(boss.id);
  const locked = !st.daily_available && !claimed;
  const ready = prog === total && !claimed && st.daily_available;
  const hp = claimed ? 0 : 100 - (prog / total) * 100;
  const hpText = weekly ? `${claimed ? 0 : 200 - prog * 50}/200` : `HP ${hp}%`;
  const label = claimed ? `✅ CLAIMED - ${boss.reward_text}` : locked ? '🔒 Locked - 1 Boss/Day Limit'
    : ready ? `🎁 DEFEAT & CLAIM ${boss.reward_text}` : `🔒 Complete all ${total} challenges`;

  return (
    <motion.article id={weekly ? 'weekly-boss-card' : undefined}
      initial={{ opacity: 0, y: 16 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true, margin: '-40px' }} transition={{ duration: 0.35 }}
      className="glass relative mb-3 overflow-hidden p-4"
      style={{ borderColor: locked ? 'rgba(255,255,255,0.05)' : boss.border, boxShadow: ready ? `0 0 20px ${boss.bg}` : undefined }}>
      <div aria-hidden className="pointer-events-none absolute -right-8 -top-8 h-28 w-28 rounded-full blur-2xl" style={{ background: boss.bg }} />
      {locked && <div className="absolute left-1/2 top-1/2 z-10 -translate-x-1/2 -translate-y-1/2 rounded-full bg-black/80 px-3.5 py-2 text-[11px] text-red-300">🔒 LOCKED</div>}
      <div className={locked ? 'opacity-40' : ''}>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className={weekly ? 'text-[48px]' : 'text-[36px]'} aria-hidden>{boss.emoji}</div>
            <div>
              <h3 className="text-[16px]">{boss.name}</h3>
              <div className="font-mono text-[10px] text-white/50">{boss.title}</div>
            </div>
          </div>
          <div className="text-right">
            <span className="rounded-full border px-2 py-0.5 text-[9px] font-bold" style={{ background: boss.bg, color: boss.color, borderColor: boss.border }}>
              {claimed ? 'CLAIMED' : weekly ? 'SUNDAY ONLY' : ready ? 'READY' : `${prog}/${total}`}
            </span>
            <div className="mt-1 font-mono text-[10px] text-white/50">{hpText}</div>
          </div>
        </div>
        <div className="mt-2.5 h-2 overflow-hidden rounded-full bg-white/10" role="progressbar" aria-label="Boss HP" aria-valuenow={hp} aria-valuemin={0} aria-valuemax={100}>
          <motion.div className="h-full rounded-full" initial={false} animate={{ width: `${hp}%` }} style={{ background: `linear-gradient(90deg, ${boss.color}, #ef4444)` }} />
        </div>
        <ul className="my-3 space-y-1.5">
          {boss.challenges.map((c) => {
            const d = done.includes(c.id);
            return (
              <li key={c.id}>
                <button role="checkbox" aria-checked={d} disabled={claimed} onClick={() => toggle(boss, c.id)}
                  className={`flex w-full items-center gap-2.5 rounded-[12px] border px-3 py-2 text-left transition-colors ${d ? 'border-[#22c55e]/30 bg-[#22c55e]/10' : 'border-white/10 bg-white/[0.04]'}`}>
                  <span className={`flex h-[18px] w-[18px] items-center justify-center rounded-[6px] border text-[11px] ${d ? 'border-[#22c55e] bg-[#22c55e] text-black' : 'border-white/20'}`}>{d ? '✓' : ''}</span>
                  <span className="text-[18px]" aria-hidden>{c.icon}</span>
                  <span className={`flex-1 text-[13px] font-bold ${d ? 'text-[#22c55e]' : ''}`}>{c.title}</span>
                  <span className={`font-mono text-[10px] ${d ? 'text-[#22c55e]' : 'text-white/30'}`}>{d ? 'DONE' : 'TODO'}</span>
                </button>
              </li>
            );
          })}
        </ul>
        <button disabled={!ready || claiming !== null} onClick={() => defeat(boss)}
          className="w-full rounded-[12px] py-3 text-[12px] font-bold transition-opacity disabled:opacity-50"
          style={ready ? { background: `linear-gradient(135deg, ${boss.color}, #ef4444)`, color: '#000' } : { background: 'rgba(255,255,255,0.06)', color: 'rgba(255,255,255,0.6)' }}>
          {claiming === boss.id ? 'Claiming…' : label}
        </button>
      </div>
    </motion.article>
  );
}
