import { z } from 'zod';
import { callRpc } from '@/lib/rpc';

export const POST = (req: Request) => callRpc(req, z.object({}), 'generate_weekly_review', (uid) => ({ p_user: uid }));
