import { z } from 'zod';
import { callRpc } from '@/lib/rpc';

const Input = z.object({ habitName: z.string().trim().min(1).max(80) });

export const POST = (req: Request) =>
  callRpc(req, Input, 'unlock_soldier', (uid, i) => ({ p_user: uid, p_habit: i.habitName }));
