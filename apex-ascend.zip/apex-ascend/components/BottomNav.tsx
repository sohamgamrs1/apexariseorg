'use client';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { Activity, LayoutGrid, Home, Mountain, ScrollText, ShoppingBag, Skull, Sparkles, Sprout, Swords, Target, Trophy } from 'lucide-react';
import { NAV } from '@/lib/data';
import { haptic } from '@/lib/haptics';

const ICONS = { Home, ScrollText, Mountain, Target, Sprout, Swords, Sparkles, Activity, Trophy, ShoppingBag, Skull, LayoutGrid };
const ACTIVE = 'scale-[1.05] border-[rgba(168,85,247,0.3)] bg-[rgba(168,85,247,0.15)] text-[#a78bfa] shadow-[0_0_12px_rgba(168,85,247,0.35),0_0_24px_rgba(168,85,247,0.15)]';

export function BottomNav() {
  const path = usePathname();
  return (
    <nav aria-label="Main" className="fixed inset-x-0 bottom-0 z-40 mx-2 mb-3">
      <div className="no-scrollbar mx-auto flex max-w-[430px] gap-[2px] overflow-x-auto rounded-[22px] border border-white/10 bg-[#0c0c12]/90 p-1 backdrop-blur-xl">
        {NAV.map((n) => {
          const Icon = ICONS[n.icon];
          const on = n.href === '/' ? path === '/' : path.startsWith(n.href);
          return (
            <Link key={n.id} id={`nav-${n.id}`} href={n.href} onClick={() => haptic(8)} aria-current={on ? 'page' : undefined}
              className={`flex min-w-[52px] flex-1 flex-col items-center gap-0.5 rounded-[16px] border px-1 py-1.5 text-[10px] transition-all ${on ? ACTIVE : 'border-transparent text-white/60'}`}>
              <Icon size={18} aria-hidden />
              <span>{n.label}</span>
            </Link>
          );
        })}
      </div>
    </nav>
  );
}
