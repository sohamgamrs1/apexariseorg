import type { Metadata, Viewport } from 'next';
import { Inter, JetBrains_Mono, Space_Grotesk } from 'next/font/google';
import './globals.css';
import { RegisterSW } from '@/components/RegisterSW';

const heading = Space_Grotesk({ subsets: ['latin'], weight: ['500', '700'], variable: '--font-heading', display: 'swap' });
const inter = Inter({ subsets: ['latin'], variable: '--font-inter', display: 'swap' });
const mono = JetBrains_Mono({ subsets: ['latin'], weight: ['400', '700'], variable: '--font-mono', display: 'swap' });

export const metadata: Metadata = {
  title: 'Apex Ascend', description: 'Defeat bosses. Build your shadow army.',
  icons: { icon: '/pwa-icon/192', apple: '/pwa-icon/192' },
  appleWebApp: { capable: true, title: 'Apex', statusBarStyle: 'black-translucent' },
};
export const viewport: Viewport = { themeColor: '#0a0a14', width: 'device-width', initialScale: 1 };

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className={`${heading.variable} ${inter.variable} ${mono.variable}`}>
      <body>{children}<RegisterSW /></body>
    </html>
  );
}
