import { z } from 'zod';
import { callRpc } from '@/lib/rpc';

export const dynamic = 'force-dynamic';
export const GET = (req: Request) => callRpc(req, z.object({}), 'boss_status', (uid) => ({ p_user: uid }));
