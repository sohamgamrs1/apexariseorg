-- Phase 3: align seeds with the original Apex Ascend V1.6 and fix consumable purchases.
alter table user_inventory add column if not exists qty int not null default 1 check (qty >= 1);

insert into avatars (id, name, tier, price, unlock_condition) values
 ('lion','Lion King','common',0,'Free'),('wolf','Shadow Wolf','common',0,'Free'),
 ('monarch','Monarch','common',0,'Free'),('flame','Flame','common',0,'Free'),
 ('frost','Frost','common',0,'Free'),('groom','Groomed','common',0,'Free'),
 ('berserker','Berserker','rare',200,'Gold Shop'),('lunar','Lunar Sage','epic',300,'Gold Shop'),
 ('rose','Rose Sorceress','rare',400,'Gold Shop'),('dragon','Dragon Emperor','legendary',500,'Gold Shop'),
 ('void','Void Eye','epic',800,'Gold Shop'),('shadow_monarch','Shadow Monarch','ultimate',1000,'Gold Shop')
on conflict (id) do update set name = excluded.name, tier = excluded.tier,
  price = excluded.price, unlock_condition = excluded.unlock_condition;

delete from gold_shop_items g
 where g.id not in ('shield','freeze','theme','extraRandom','xpBoost','nameToken',
   'avatar_berserker','avatar_dragon','avatar_lunar','avatar_rose','avatar_void','avatar_shadow')
   and not exists (select 1 from user_inventory i where i.item_id = g.id);

insert into gold_shop_items (id, name, icon, cost, "desc", is_avatar, avatar_id) values
 ('shield','Shield','🛡️',100,'Saves 1 missed day, weekly protection',false,null),
 ('freeze','Streak Freeze','❄️',150,'Freeze streak for 1 day without shield',false,null),
 ('theme','Theme Unlock','🎨',50,'Unlock 1 random premium theme',false,null),
 ('extraRandom','Extra Random','🎲',30,'Extra random refresh beyond daily limit',false,null),
 ('xpBoost','XP Boost 2x','✨',80,'2x XP for next 24 hours',false,null),
 ('nameToken','Name Change Token','🔄',40,'Required to change hunter name',false,null),
 ('avatar_berserker','Berserker Avatar','⚔️',200,'Unlock Berserker avatar',true,'berserker'),
 ('avatar_lunar','Lunar Sage','🌙',300,'Unlock Lunar Sage avatar',true,'lunar'),
 ('avatar_rose','Rose Sorceress','🌹',400,'Unlock Rose Sorceress avatar',true,'rose'),
 ('avatar_dragon','Dragon Emperor','🐉',500,'Unlock Dragon Emperor avatar',true,'dragon'),
 ('avatar_void','Void Eye','👁️',800,'Unlock Void Eye avatar',true,'void'),
 ('avatar_shadow','Shadow Monarch','🌑',1000,'Unlock Shadow Monarch avatar',true,'shadow_monarch')
on conflict (id) do update set name = excluded.name, icon = excluded.icon, cost = excluded.cost,
  "desc" = excluded."desc", is_avatar = excluded.is_avatar, avatar_id = excluded.avatar_id;

-- Consumables stack (qty + 1); avatars still can only be bought once. Grants are kept by CREATE OR REPLACE.
create or replace function purchase_item(p_user uuid, p_item text) returns jsonb
language plpgsql security definer set search_path = public as $$
declare v_item gold_shop_items%rowtype; v_gold int;
begin
  select * into v_item from gold_shop_items where id = p_item;
  if not found then raise exception 'UNKNOWN_ITEM'; end if;
  if v_item.is_avatar and exists (select 1 from user_inventory where user_id = p_user and item_id = p_item)
    then raise exception 'ALREADY_OWNED'; end if;

  update hunters set gold = gold - v_item.cost where id = p_user and gold >= v_item.cost returning gold into v_gold;
  if not found then raise exception 'INSUFFICIENT_GOLD'; end if;

  insert into user_inventory (user_id, item_id) values (p_user, p_item)
    on conflict (user_id, item_id) do update set qty = user_inventory.qty + 1;
  return jsonb_build_object('purchased', p_item, 'gold', v_gold);
end $$;
