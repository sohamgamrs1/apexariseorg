import { NextResponse } from 'next/server';
import { z } from 'zod';
import { createServerClient } from '@/lib/supabase/server';
import { createAdminClient } from '@/lib/supabase/admin';

const STATUS: Record<string, number> = {
  DAILY_LIMIT: 429, INCOMPLETE: 422, UNKNOWN_BOSS: 404, UNKNOWN_ITEM: 404, ALREADY_OWNED: 409,
  INSUFFICIENT_GOLD: 402, NO_HUNTER: 404, NO_ACTIVE_RUN: 404, TOO_EARLY: 409, ALREADY_FINISHED: 409,
  ARMY_DAILY_CAP: 429, ARMY_FULL: 409, NOT_SUNDAY: 403, UNKNOWN_QUEST: 404, ALREADY_DONE: 409, QUESTS_STARTED: 409, ROLL_LIMIT: 429,
  ALREADY_RESET: 409, NOTHING_DONE: 409, QUEST_LIMIT: 409, NO_NAME_TOKEN: 402, BAD_NAME: 400, COMING_SOON: 409,
};

/** Auth + validate (JSON body, or query string for GET) + call a service-role RPC; map PG errors to HTTP codes. */
export async function callRpc<T extends z.ZodTypeAny>(
  req: Request, schema: T, fn: string, args: (userId: string, input: z.infer<T>) => Record<string, unknown>,
) {
  const { data: { user } } = await createServerClient().auth.getUser();
  if (!user) return NextResponse.json({ error: 'UNAUTHORIZED' }, { status: 401 });

  const raw = req.method === 'GET'
    ? Object.fromEntries(new URL(req.url).searchParams)
    : await req.json().catch(() => ({}));
  const parsed = schema.safeParse(raw);
  if (!parsed.success) return NextResponse.json({ error: 'BAD_REQUEST' }, { status: 400 });

  const { data, error } = await createAdminClient().rpc(fn, args(user.id, parsed.data));
  if (error) {
    const code = Object.keys(STATUS).find((k) => error.message.includes(k));
    return NextResponse.json({ error: code ?? 'SERVER_ERROR' }, { status: code ? STATUS[code] : 500 });
  }
  return NextResponse.json(data);
}
