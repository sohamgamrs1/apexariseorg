'use client';
import { useState } from 'react';
import Link from 'next/link';
import { Coach } from '@/components/hub/Coach';
import { Dungeon } from '@/components/hub/Dungeon';
import { Journal } from '@/components/hub/Journal';
import { ShadowArmy } from '@/components/hub/ShadowArmy';
import { WeeklyReview } from '@/components/hub/WeeklyReview';

const TABS = [['shadow', '👥 Shadow Army'], ['dungeon', '🏰 Dungeon'], ['journal', '📓 Journal'], ['weekly', '📊 Weekly Review'], ['coach', '🤖 AI Coach']] as const;
type Tab = (typeof TABS)[number][0];

export default function FeaturesHub() {
  const [tab, setTab] = useState<Tab>('shadow');
  return (
    <div id="features-hub-page">
      <Link href="/" className="inline-block rounded-full border border-white/15 bg-white/10 px-3.5 py-2 text-[12px]">← Back</Link>
      <div className="my-4 text-center">
        <h1 className="text-[24px] italic">Apex Features Hub</h1>
        <p className="mt-1 text-[11px] text-white/50">Shadow Army · Dungeon · Journal · Weekly · AI Coach</p>
      </div>
      <div id="feature-tabs" role="tablist" className="no-scrollbar mb-4 flex gap-2 overflow-x-auto">
        {TABS.map(([id, label]) => (
          <button key={id} role="tab" aria-selected={tab === id} onClick={() => setTab(id)}
            className={`shrink-0 rounded-full border px-3.5 py-2 text-[12px] transition-colors ${tab === id ? 'border-[rgba(168,85,247,0.3)] bg-[rgba(168,85,247,0.15)] text-[#a78bfa]' : 'border-white/10 bg-white/[0.04] text-white/60'}`}>{label}</button>
        ))}
      </div>
      {tab === 'shadow' && <ShadowArmy />}
      {tab === 'dungeon' && <Dungeon />}
      {tab === 'journal' && <Journal />}
      {tab === 'weekly' && <WeeklyReview />}
      {tab === 'coach' && <Coach />}
    </div>
  );
}
