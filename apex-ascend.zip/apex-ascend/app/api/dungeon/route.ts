import { z } from 'zod';
import { callRpc } from '@/lib/rpc';

const Input = z.object({});

export const GET = (req: Request) =>
  callRpc(req, Input, 'dungeon_state', (uid) => ({ p_user: uid }));
