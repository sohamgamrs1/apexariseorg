import { ImageResponse } from 'next/og';
import { NextResponse } from 'next/server';
import { AVATARS } from '@/lib/data';
import { createServerClient } from '@/lib/supabase/server';
import { createAdminClient } from '@/lib/supabase/admin';

export const dynamic = 'force-dynamic';

// 1080x1920 hunter card, rendered server-side so it looks identical on every device. No emoji: the card uses text only.
export async function GET() {
  const { data: { user } } = await createServerClient().auth.getUser();
  if (!user) return NextResponse.json({ error: 'UNAUTHORIZED' }, { status: 401 });

  const db = createAdminClient();
  const [h, army, slain] = await Promise.all([
    db.from('hunters').select('name,avatar_id,level,gold,best_streak,titles').eq('id', user.id).single(),
    db.rpc('army_status', { p_user: user.id }),
    db.from('glory_logs').select('id', { count: 'exact', head: true }).eq('user_id', user.id).neq('challenge_id', 'dungeon'),
  ]);
  if (h.error) return NextResponse.json({ error: 'NO_HUNTER' }, { status: 404 });

  const av = AVATARS.find((a) => a.id === h.data.avatar_id) ?? AVATARS[0];
  const stats: [string, string][] = [
    ['Level', String(h.data.level)], ['Gold', String(h.data.gold)], ['Best streak', `${h.data.best_streak} days`],
    ['Army power', String(army.data?.power ?? 0)], ['Bosses slain', String(slain.count ?? 0)], ['Titles', String(h.data.titles?.length ?? 0)],
  ];
  const flex = { display: 'flex' } as const;

  return new ImageResponse(
    (
      <div style={{ ...flex, width: '100%', height: '100%', flexDirection: 'column', alignItems: 'center', padding: '120px 80px', color: '#fff',
        backgroundImage: 'linear-gradient(180deg,#0a0a14 0%,#1a0a2e 50%,#0a0a14 100%)' }}>
        <div style={{ ...flex, fontSize: 96, fontWeight: 800, letterSpacing: -2 }}>APEX ASCEND</div>
        <div style={{ ...flex, fontSize: 30, color: '#a78bfa', marginTop: 12, letterSpacing: 8 }}>HUNTER CARD</div>
        <div style={{ ...flex, width: 260, height: 260, borderRadius: 130, marginTop: 120, alignItems: 'center', justifyContent: 'center',
          fontSize: 120, fontWeight: 800, backgroundImage: av.grad, border: '6px solid rgba(168,85,247,0.6)' }}>
          {h.data.name.trim().charAt(0).toUpperCase() || 'H'}
        </div>
        <div style={{ ...flex, fontSize: 64, fontWeight: 800, marginTop: 48 }}>{h.data.name}</div>
        <div style={{ ...flex, fontSize: 32, color: 'rgba(255,255,255,0.6)', marginTop: 8 }}>{`LVL ${h.data.level} · ${army.data?.rank ?? 'Recruit'}`}</div>
        <div style={{ ...flex, flexWrap: 'wrap', width: 920, marginTop: 110 }}>
          {stats.map(([label, value]) => (
            <div key={label} style={{ ...flex, flexDirection: 'column', width: 448, padding: 36, margin: 12, borderRadius: 32,
              background: 'rgba(255,255,255,0.05)', border: '2px solid rgba(255,255,255,0.1)' }}>
              <div style={{ ...flex, fontSize: 72, fontWeight: 800 }}>{value}</div>
              <div style={{ ...flex, fontSize: 26, color: 'rgba(255,255,255,0.55)', marginTop: 6, textTransform: 'uppercase', letterSpacing: 3 }}>{label}</div>
            </div>
          ))}
        </div>
        <div style={{ ...flex, marginTop: 'auto', fontSize: 34, fontStyle: 'italic', color: '#a78bfa' }}>Discipline is the weapon.</div>
      </div>
    ),
    { width: 1080, height: 1920, headers: { 'Cache-Control': 'no-store' } },
  );
}
