import { z } from 'zod';
import { callRpc } from '@/lib/rpc';

export const POST = (req: Request) =>
  callRpc(req, z.object({ name: z.string().trim().min(1).max(20) }), 'rename_hunter', (uid, b) => ({ p_user: uid, p_name: b.name }));
