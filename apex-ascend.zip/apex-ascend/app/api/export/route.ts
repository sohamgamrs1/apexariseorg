import { NextResponse } from 'next/server';
import { createServerClient } from '@/lib/supabase/server';
import { createAdminClient } from '@/lib/supabase/admin';

export const dynamic = 'force-dynamic';

export async function GET() {
  const { data: { user } } = await createServerClient().auth.getUser();
  if (!user) return NextResponse.json({ error: 'UNAUTHORIZED' }, { status: 401 });
  const db = createAdminClient(); const u = user.id;
  const [h, inv, j, g, army, wr, cm, dr] = await Promise.all([
    db.from('hunters').select('name,avatar_id,level,xp,gold,streak,best_streak,titles,created_at').eq('id', u).single(),
    db.from('user_inventory').select('item_id,qty,purchased_at').eq('user_id', u),
    db.from('journal_entries').select('date,win,learn,tomorrow,mood,streak_snapshot').eq('user_id', u).order('date', { ascending: false }).limit(1000),
    db.from('glory_logs').select('challenge_id,glory_title,challenge_title,xp,gold,date,duration').eq('user_id', u).order('date', { ascending: false }).limit(1000),
    db.from('shadow_army').select('soldier_index,habit_name,unlocked_at').eq('user_id', u).eq('unlocked', true),
    db.from('weekly_reviews').select('week_start,content').eq('user_id', u).order('week_start', { ascending: false }).limit(30),
    db.from('coach_messages').select('role,content,created_at').eq('user_id', u).order('created_at', { ascending: false }).limit(100),
    db.from('dungeon_runs').select('start_time,end_time,status,best_time').eq('user_id', u).order('start_time', { ascending: false }).limit(200),
  ]);
  return NextResponse.json({
    app: 'apex-ascend', version: 1, exported_at: new Date().toISOString(),
    hunter: h.data, inventory: inv.data ?? [], journal_entries: j.data ?? [], glory_logs: g.data ?? [],
    shadow_army: army.data ?? [], weekly_reviews: wr.data ?? [], coach_messages: cm.data ?? [], dungeon_runs: dr.data ?? [],
  });
}
