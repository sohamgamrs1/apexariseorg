import { z } from 'zod';
import { callRpc } from '@/lib/rpc';

const Input = z.object({ win: z.string().max(2000).default(""), learn: z.string().max(2000).default(""), tomorrow: z.string().max(2000).default(""), mood: z.string().max(16).default('') }).refine((v) => v.win || v.learn || v.tomorrow);

export const POST = (req: Request) =>
  callRpc(req, Input, 'save_journal', (uid, i) => ({ p_user: uid, p_win: i.win, p_learn: i.learn, p_tomorrow: i.tomorrow, p_mood: i.mood }));
