import { z } from 'zod';
import { callRpc } from '@/lib/rpc';

export const POST = (req: Request) =>
  callRpc(req, z.object({ questId: z.string().uuid() }), 'delete_quest', (uid, b) => ({ p_user: uid, p_quest: b.questId }));
