-- Phase 6: original progression engine (level curve, 5 stats, XP boost), server-side quests, shop/rename. Run after 005.
alter table hunters add column if not exists need int not null default 100;
alter table hunters add column if not exists points int not null default 0;
alter table hunters add column if not exists stat_str int not null default 10;
alter table hunters add column if not exists stat_int int not null default 10;
alter table hunters add column if not exists stat_agi int not null default 10;
alter table hunters add column if not exists stat_vit int not null default 10;
alter table hunters add column if not exists stat_sen int not null default 10;
alter table hunters add column if not exists xp_boost_until timestamptz;
-- Move any existing test data onto the new curve (need = 100 * 1.18^(level-1)).
update hunters set need = round(100 * power(1.18::numeric, level - 1))::int;
update hunters set xp = least(xp, need - 1);

-- Single place that pays out XP/gold/stat: 2x while an XP Boost is active; level-up grows `need` by 18% and gives 5 points.
create or replace function grant_progress(p_user uuid, p_xp int, p_gold int, p_stat text default null) returns jsonb
language plpgsql security definer set search_path = public as $$
declare h hunters%rowtype; v_mult int; v_xp int; v_need int; v_lvl int; v_pts int; v_up int := 0;
begin
  select * into h from hunters where id = p_user for update;
  if not found then raise exception 'NO_HUNTER'; end if;
  v_mult := case when h.xp_boost_until is not null and h.xp_boost_until > now() then 2 else 1 end;
  v_xp := h.xp + p_xp * v_mult; v_need := h.need; v_lvl := h.level; v_pts := h.points;
  while v_xp >= v_need loop
    v_xp := v_xp - v_need; v_need := round(v_need * 1.18)::int; v_lvl := v_lvl + 1; v_pts := v_pts + 5; v_up := v_up + 1;
  end loop;
  update hunters set xp = v_xp, need = v_need, level = v_lvl, points = v_pts, gold = gold + p_gold, last_active = ist_today(),
    stat_str = stat_str + case when p_stat = 'str' then 1 else 0 end, stat_int = stat_int + case when p_stat = 'int' then 1 else 0 end,
    stat_agi = stat_agi + case when p_stat = 'agi' then 1 else 0 end, stat_vit = stat_vit + case when p_stat = 'vit' then 1 else 0 end,
    stat_sen = stat_sen + case when p_stat = 'sen' then 1 else 0 end
  where id = p_user returning * into h;
  return jsonb_build_object('xp', h.xp, 'need', h.need, 'level', h.level, 'points', h.points, 'gold', h.gold,
    'stat_str', h.stat_str, 'stat_int', h.stat_int, 'stat_agi', h.stat_agi, 'stat_vit', h.stat_vit, 'stat_sen', h.stat_sen,
    'levels_gained', v_up, 'xp_gained', p_xp * v_mult, 'boosted', v_mult = 2);
end $$;

-- Boss defeat now uses the shared progression engine.
create or replace function defeat_boss(p_user uuid, p_boss text, p_done text[]) returns jsonb
language plpgsql security definer set search_path = public as $$
declare v_boss challenger_bosses%rowtype; v_today date := ist_today(); v_total int; v_valid int; v_xp int; v_g jsonb;
begin
  select * into v_boss from challenger_bosses where id = p_boss;
  if not found then raise exception 'UNKNOWN_BOSS'; end if;
  if v_boss.is_weekly and extract(dow from v_today) <> 0 then raise exception 'NOT_SUNDAY'; end if;
  select count(*), coalesce(sum(xp),0) into v_total, v_xp from boss_challenges where boss_id = p_boss;
  select count(distinct c) into v_valid from unnest(p_done) c where c in (select id from boss_challenges where boss_id = p_boss);
  if v_valid < v_total then raise exception 'INCOMPLETE'; end if;
  insert into daily_boss_limit (user_id, date, count) values (p_user, v_today, 1) on conflict (user_id, date) do nothing;
  if not found then raise exception 'DAILY_LIMIT'; end if;

  v_g := grant_progress(p_user, v_xp, v_boss.gold_reward);
  update hunters set titles = case when v_boss.reward_title is null or v_boss.reward_title = any(titles) then titles
                                   else array_append(titles, v_boss.reward_title) end where id = p_user;
  insert into glory_logs (user_id, challenge_id, glory_title, challenge_title, icon, color, xp, gold, date)
  values (p_user, p_boss, 'Boss Slayer: ' || v_boss.name, v_boss.name, v_boss.emoji, v_boss.color, v_xp, v_boss.gold_reward, v_today);
  if v_boss.is_weekly then
    insert into weekly_boss_state (user_id, week_start, hp, max_hp, is_defeated, defeated_at) values (p_user, v_today, 0, 200, true, now())
    on conflict (user_id, week_start) do update set hp = 0, is_defeated = true, defeated_at = now();
  end if;
  return v_g || jsonb_build_object('defeated', true, 'boss', v_boss.name, 'reward_gold', v_boss.gold_reward, 'reward_xp', v_xp, 'title', v_boss.reward_title);
end $$;

-- ---------- Quests (original rules: 5 random from a pool of 16; 10-20 XP, 5-10 gold) ----------
create table if not exists quest_pool (id serial primary key, title text not null, "desc" text not null,
  stat text not null check (stat in ('str','int','agi','vit','sen')));
insert into quest_pool (title, "desc", stat) select * from (values
 ('Push-ups 30','Chest pump','str'),('Walk 2km','Active recovery','vit'),('Journal 10min','Reflect mind','int'),('Squats 40','Leg strength','str'),
 ('Cold Shower','Mental grit','vit'),('Skill 1hr','Learn craft','int'),('Study 90min','Deep focus','int'),('Meditation 10min','Calm mind','sen'),
 ('Read 20 pages','Knowledge','int'),('Drink 3L water','Hydrate','vit'),('No phone 1hr','Detox','sen'),('Plan tomorrow','Strategic','int'),
 ('Grooming','Look sharp','agi'),('Neck Curls 50','Posture','str'),('Mewing check','Jawline','agi'),('Speak less','Observe more','sen')
) v(t, d, s) where not exists (select 1 from quest_pool);

create table if not exists quests (
  id uuid primary key default gen_random_uuid(), user_id uuid not null references hunters(id) on delete cascade,
  title text not null check (length(title) between 1 and 16), "desc" text not null default '' check (length("desc") <= 20),
  stat text not null check (stat in ('str','int','agi','vit','sen')),
  xp int not null check (xp between 1 and 30), gold int not null check (gold between 1 and 15),
  done boolean not null default false, is_custom boolean not null default false, created_at timestamptz not null default now()
);
create index if not exists quests_user on quests (user_id);
create table if not exists quest_day (user_id uuid not null references hunters(id) on delete cascade, date date not null,
  rolls int not null default 0, reset_used boolean not null default false, primary key (user_id, date));
alter table quests enable row level security; alter table quest_day enable row level security; alter table quest_pool enable row level security;
create policy "own quests read" on quests for select using (user_id = auth.uid());
create policy "own quest_day read" on quest_day for select using (user_id = auth.uid());
create policy "pool read" on quest_pool for select using (true);

create or replace function roll_quests(p_user uuid) returns void language plpgsql security definer set search_path = public as $$
begin
  delete from quests where user_id = p_user;
  insert into quests (user_id, title, "desc", stat, xp, gold)
  select p_user, title, "desc", stat, 10 + floor(random() * 11)::int, 5 + floor(random() * 6)::int from quest_pool order by random() limit 5;
end $$;

create or replace function get_quests(p_user uuid) returns jsonb language plpgsql security definer set search_path = public as $$
declare v_extra int; v_qd quest_day%rowtype;
begin
  perform 1 from hunters where id = p_user for update;
  if not found then raise exception 'NO_HUNTER'; end if;
  if not exists (select 1 from quests where user_id = p_user) then perform roll_quests(p_user); end if;
  select coalesce(sum(qty), 0) into v_extra from user_inventory where user_id = p_user and item_id = 'extraRandom';
  select * into v_qd from quest_day where user_id = p_user and date = ist_today();
  return jsonb_build_object('rolls_used', coalesce(v_qd.rolls, 0), 'rolls_max', 3 + v_extra, 'reset_used', coalesce(v_qd.reset_used, false),
    'quests', (select coalesce(jsonb_agg(jsonb_build_object('id', id, 'title', title, 'desc', "desc", 'stat', stat, 'xp', xp, 'gold', gold,
      'done', done, 'custom', is_custom) order by created_at, id), '[]'::jsonb) from quests where user_id = p_user));
end $$;

-- Completing a quest pays XP/gold, raises its stat by 1, and tries to recruit a shadow soldier (daily cap applies).
create or replace function complete_quest(p_user uuid, p_quest uuid) returns jsonb
language plpgsql security definer set search_path = public as $$
declare q quests%rowtype; v_g jsonb; v_soldier boolean := false;
begin
  select * into q from quests where id = p_quest and user_id = p_user for update;
  if not found then raise exception 'UNKNOWN_QUEST'; end if;
  if q.done then raise exception 'ALREADY_DONE'; end if;
  update quests set done = true where id = q.id;
  v_g := grant_progress(p_user, q.xp, q.gold, q.stat);
  begin perform unlock_soldier(p_user, q.title); v_soldier := true; exception when others then v_soldier := false; end;
  return v_g || jsonb_build_object('soldier', v_soldier, 'quest_gold', q.gold);
end $$;

-- 3 re-rolls a day, +1 per Extra Random credit (credit is spent from the 4th roll on); blocked once any quest is done.
create or replace function randomize_quests(p_user uuid) returns jsonb language plpgsql security definer set search_path = public as $$
declare v_today date := ist_today(); v_rolls int; v_extra int;
begin
  perform 1 from hunters where id = p_user for update;
  if not found then raise exception 'NO_HUNTER'; end if;
  if exists (select 1 from quests where user_id = p_user and done) then raise exception 'QUESTS_STARTED'; end if;
  insert into quest_day (user_id, date) values (p_user, v_today) on conflict do nothing;
  select rolls into v_rolls from quest_day where user_id = p_user and date = v_today;
  select coalesce(sum(qty), 0) into v_extra from user_inventory where user_id = p_user and item_id = 'extraRandom';
  if v_rolls >= 3 + v_extra then raise exception 'ROLL_LIMIT'; end if;
  if v_rolls >= 3 then
    delete from user_inventory where user_id = p_user and item_id = 'extraRandom' and qty = 1;
    update user_inventory set qty = qty - 1 where user_id = p_user and item_id = 'extraRandom' and qty > 1;
  end if;
  update quest_day set rolls = rolls + 1 where user_id = p_user and date = v_today;
  perform roll_quests(p_user);
  return get_quests(p_user);
end $$;

-- Once per day, un-tick every quest so it can be done again.
create or replace function reset_daily_quests(p_user uuid) returns jsonb language plpgsql security definer set search_path = public as $$
declare v_today date := ist_today(); v_used boolean;
begin
  perform 1 from hunters where id = p_user for update;
  if not found then raise exception 'NO_HUNTER'; end if;
  insert into quest_day (user_id, date) values (p_user, v_today) on conflict do nothing;
  select reset_used into v_used from quest_day where user_id = p_user and date = v_today;
  if v_used then raise exception 'ALREADY_RESET'; end if;
  if not exists (select 1 from quests where user_id = p_user and done) then raise exception 'NOTHING_DONE'; end if;
  update quests set done = false where user_id = p_user;
  update quest_day set reset_used = true where user_id = p_user and date = v_today;
  return get_quests(p_user);
end $$;

create or replace function add_quest(p_user uuid, p_title text, p_desc text, p_stat text, p_xp int, p_gold int) returns jsonb
language plpgsql security definer set search_path = public as $$
begin
  perform 1 from hunters where id = p_user for update;
  if not found then raise exception 'NO_HUNTER'; end if;
  if (select count(*) from quests where user_id = p_user) >= 20 then raise exception 'QUEST_LIMIT'; end if;
  insert into quests (user_id, title, "desc", stat, xp, gold, is_custom) values (p_user, btrim(p_title), btrim(p_desc), p_stat, p_xp, p_gold, true);
  return get_quests(p_user);
end $$;

create or replace function delete_quest(p_user uuid, p_quest uuid) returns jsonb language plpgsql security definer set search_path = public as $$
begin
  delete from quests where id = p_quest and user_id = p_user;
  return get_quests(p_user);
end $$;

-- ---------- Shop: XP Boost is an active 24h effect; Shield/Freeze/Theme are blocked until their screens exist ----------
create or replace function purchase_item(p_user uuid, p_item text) returns jsonb
language plpgsql security definer set search_path = public as $$
declare v_item gold_shop_items%rowtype; v_gold int; v_boost timestamptz;
begin
  if p_item in ('shield', 'freeze', 'theme') then raise exception 'COMING_SOON'; end if;
  select * into v_item from gold_shop_items where id = p_item;
  if not found then raise exception 'UNKNOWN_ITEM'; end if;
  if v_item.is_avatar and exists (select 1 from user_inventory where user_id = p_user and item_id = p_item) then raise exception 'ALREADY_OWNED'; end if;
  update hunters set gold = gold - v_item.cost where id = p_user and gold >= v_item.cost returning gold into v_gold;
  if not found then raise exception 'INSUFFICIENT_GOLD'; end if;
  if p_item = 'xpBoost' then
    update hunters set xp_boost_until = greatest(now(), coalesce(xp_boost_until, now())) + interval '24 hours'
    where id = p_user returning xp_boost_until into v_boost;
  else
    insert into user_inventory (user_id, item_id) values (p_user, p_item)
    on conflict (user_id, item_id) do update set qty = user_inventory.qty + 1;
  end if;
  return jsonb_build_object('purchased', p_item, 'gold', v_gold, 'xp_boost_until', v_boost);
end $$;

-- Renaming consumes one Name Token.
create or replace function rename_hunter(p_user uuid, p_name text) returns jsonb language plpgsql security definer set search_path = public as $$
declare v_name text := btrim(p_name);
begin
  if length(v_name) not between 1 and 20 then raise exception 'BAD_NAME'; end if;
  perform 1 from hunters where id = p_user for update;
  if not found then raise exception 'NO_HUNTER'; end if;
  if not exists (select 1 from user_inventory where user_id = p_user and item_id = 'nameToken') then raise exception 'NO_NAME_TOKEN'; end if;
  delete from user_inventory where user_id = p_user and item_id = 'nameToken' and qty = 1;
  update user_inventory set qty = qty - 1 where user_id = p_user and item_id = 'nameToken' and qty > 1;
  update hunters set name = v_name where id = p_user;
  return jsonb_build_object('name', v_name);
end $$;

revoke all on function grant_progress(uuid,int,int,text), roll_quests(uuid) from public, anon, authenticated, service_role;
revoke all on function get_quests(uuid), complete_quest(uuid,uuid), randomize_quests(uuid), reset_daily_quests(uuid),
  add_quest(uuid,text,text,text,int,int), delete_quest(uuid,uuid), rename_hunter(uuid,text) from public, anon, authenticated;
grant execute on function get_quests(uuid), complete_quest(uuid,uuid), randomize_quests(uuid), reset_daily_quests(uuid),
  add_quest(uuid,text,text,text,int,int), delete_quest(uuid,uuid), rename_hunter(uuid,text) to service_role;
