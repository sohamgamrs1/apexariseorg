import { z } from 'zod';
import { callRpc } from '@/lib/rpc';

const Body = z.object({ itemId: z.string().min(1) });

export const POST = (req: Request) =>
  callRpc(req, Body, 'purchase_item', (uid, b) => ({ p_user: uid, p_item: b.itemId }));
