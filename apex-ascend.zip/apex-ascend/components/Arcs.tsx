'use client';
import { CHALLENGES } from '@/lib/data';
import { istToday, useApex } from '@/lib/store';

const dayOf = (start: string, duration: number) =>
  Math.min(Math.max(Math.floor((Date.parse(istToday()) - Date.parse(start)) / 86_400_000) + 1, 1), duration);

export function Arcs() {
  const arcs = useApex((s) => s.arcs);
  const start = useApex((s) => s.startArc);
  return (
    <section className="glass p-4" aria-labelledby="arcs-h">
      <h2 id="arcs-h" className="mb-3 text-[15px]">Active Challenges</h2>
      <ul className="space-y-2">
        {CHALLENGES.map((c) => {
          const startedOn = arcs[c.id];
          const day = startedOn ? dayOf(startedOn, c.duration) : 0;
          return (
            <li key={c.id} className="rounded-[14px] border border-white/10 bg-white/[0.04] p-3">
              <div className="flex items-center gap-3">
                <span className="text-[22px]" aria-hidden>{c.icon}</span>
                <div className="min-w-0 flex-1">
                  <div className="truncate text-[14px] font-bold">{c.title}</div>
                  <div className="text-[11px] text-white/60">{c.duration} days · {c.difficulty}</div>
                </div>
                {startedOn
                  ? <span className="font-mono text-[12px]" style={{ color: c.color }}>Day {day}/{c.duration}</span>
                  : <button onClick={() => start(c.id, c.title)} className="rounded-full border px-3 py-1 text-[12px]" style={{ borderColor: c.color, color: c.color }}>Start</button>}
              </div>
              {startedOn && (
                <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-white/10" role="progressbar" aria-valuenow={day} aria-valuemin={0} aria-valuemax={c.duration}>
                  <div className="h-full rounded-full" style={{ width: `${(day / c.duration) * 100}%`, background: c.color }} />
                </div>
              )}
            </li>
          );
        })}
      </ul>
    </section>
  );
}
