import { NextResponse } from 'next/server';
import { z } from 'zod';
import { createServerClient } from '@/lib/supabase/server';
import { createAdminClient } from '@/lib/supabase/admin';

// { avatarId } equips a preset (must be free or owned); { custom: true } points the hunter at their uploaded image.
const Body = z.union([z.object({ avatarId: z.string().min(1).max(40) }), z.object({ custom: z.literal(true) })]);
const CODES: Record<string, number> = { AVATAR_LOCKED: 403, UNKNOWN_AVATAR: 404, NO_HUNTER: 404 };

export async function POST(req: Request) {
  const { data: { user } } = await createServerClient().auth.getUser();
  if (!user) return NextResponse.json({ error: 'UNAUTHORIZED' }, { status: 401 });
  const parsed = Body.safeParse(await req.json().catch(() => null));
  if (!parsed.success) return NextResponse.json({ error: 'BAD_REQUEST' }, { status: 400 });

  const db = createAdminClient();
  if ('custom' in parsed.data) {
    // The path is fixed per user, so the URL is built here rather than trusted from the client.
    const url = `${process.env.NEXT_PUBLIC_SUPABASE_URL}/storage/v1/object/public/avatars/${user.id}/avatar.png?v=${Date.now()}`;
    const { error } = await db.from('hunters').update({ custom_avatar_url: url }).eq('id', user.id);
    return error ? NextResponse.json({ error: 'SERVER_ERROR' }, { status: 500 }) : NextResponse.json({ custom_avatar_url: url });
  }
  const { error } = await db.rpc('select_avatar', { p_user: user.id, p_avatar: parsed.data.avatarId });
  if (error) {
    const code = Object.keys(CODES).find((k) => error.message.includes(k));
    return NextResponse.json({ error: code ?? 'SERVER_ERROR' }, { status: code ? CODES[code] : 500 });
  }
  return NextResponse.json({ avatar_id: parsed.data.avatarId });
}
