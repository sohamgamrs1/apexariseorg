import { z } from 'zod';
import { callRpc } from '@/lib/rpc';

export const dynamic = 'force-dynamic';

const Add = z.object({
  title: z.string().trim().min(1).max(16), desc: z.string().trim().max(20).default(''),
  stat: z.enum(['str', 'int', 'agi', 'vit', 'sen']), xp: z.number().int().min(1).max(30), gold: z.number().int().min(1).max(15),
});

export const GET = (req: Request) => callRpc(req, z.object({}), 'get_quests', (uid) => ({ p_user: uid }));
export const POST = (req: Request) =>
  callRpc(req, Add, 'add_quest', (uid, b) => ({ p_user: uid, p_title: b.title, p_desc: b.desc, p_stat: b.stat, p_xp: b.xp, p_gold: b.gold }));
