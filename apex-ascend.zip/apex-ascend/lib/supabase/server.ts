import { createServerClient as create } from '@supabase/ssr';
import { cookies } from 'next/headers';

export function createServerClient() {
  const store = cookies();
  return create(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!, {
    cookies: {
      get: (n) => store.get(n)?.value,
      set: (n, v, o) => { try { store.set({ name: n, value: v, ...o }); } catch {} },
      remove: (n, o) => { try { store.set({ name: n, value: '', ...o }); } catch {} },
    },
  });
}
