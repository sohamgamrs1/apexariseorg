'use client';
import { Shop } from '@/components/Shop';
import { useApex } from '@/lib/store';

const INVENTORY = [['extraRandom', '🎲', 'Extra Random'], ['nameToken', '🔄', 'Name Tokens']] as const;

export default function ShopPage() {
  const hunter = useApex((s) => s.hunter);
  const owned = useApex((s) => s.owned);
  const boosted = !!hunter?.xp_boost_until && new Date(hunter.xp_boost_until) > new Date();
  return (
    <div className="space-y-4">
      <section className="glass flex items-center justify-between p-4">
        <h1 className="text-[20px]">Gold Shop</h1>
        <span className="rounded-full bg-amber-400/10 px-3 py-1 text-[14px] font-bold text-amber-300">🪙 {hunter?.gold ?? 0}</span>
      </section>
      <section className="glass p-4" aria-labelledby="inv-h">
        <h2 id="inv-h" className="mb-3 text-[13px]">Inventory</h2>
        <div className="grid grid-cols-2 gap-2 text-center">
          {INVENTORY.map(([id, icon, label]) => (
            <div key={id} className="rounded-[14px] bg-white/[0.04] py-3"><div className="text-[20px]" aria-hidden>{icon}</div><div className="text-[18px] font-bold">{owned[id] ?? 0}</div><div className="text-[10px] text-white/50">{label}</div></div>
          ))}
        </div>
        <p className="mt-3 text-center text-[12px] text-white/60">{boosted ? `✨ 2x XP active until ${new Date(hunter!.xp_boost_until!).toLocaleString()}` : 'No XP Boost active'}</p>
      </section>
      <Shop />
    </div>
  );
}
