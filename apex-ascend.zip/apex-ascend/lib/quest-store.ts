'use client';
import { create } from 'zustand';
import { api, ERRORS } from './api';
import { haptic } from './haptics';
import { useApex, type Hunter } from './store';

export type Stat = 'str' | 'int' | 'agi' | 'vit' | 'sen';
export type Quest = { id: string; title: string; desc: string; stat: Stat; xp: number; gold: number; done: boolean; custom: boolean };
type Snapshot = { quests: Quest[]; rolls_used: number; rolls_max: number; reset_used: boolean };
type Progress = Pick<Hunter, 'xp' | 'need' | 'level' | 'points' | 'gold' | 'stat_str' | 'stat_int' | 'stat_agi' | 'stat_vit' | 'stat_sen'> &
  { levels_gained: number; xp_gained: number; boosted: boolean; soldier: boolean; quest_gold: number };
export type NewQuest = { title: string; desc: string; stat: Stat; xp: number; gold: number };

const QERR: Record<string, string> = {
  ...ERRORS, QUESTS_STARTED: "Can't randomize after starting quests. Reset daily first.", ROLL_LIMIT: 'No rolls left today. Buy Extra Random in the Shop.',
  ALREADY_RESET: 'Already reset today.', NOTHING_DONE: 'No quests done yet.', QUEST_LIMIT: 'Quest limit reached (20).',
};

interface State {
  data: Snapshot | null; loading: boolean; error: boolean; busy: boolean;
  load: () => Promise<void>;
  complete: (q: Quest) => Promise<void>;
  randomize: () => Promise<void>;
  reset: () => Promise<void>;
  add: (q: NewQuest) => Promise<boolean>;
  remove: (id: string) => Promise<void>;
}

export const useQuests = create<State>((set, get) => {
  // Shared path for actions that return a fresh snapshot.
  async function act(path: string, body: unknown, ok?: string) {
    if (get().busy) return false;
    set({ busy: true });
    const r = await api<Snapshot>(path, 'POST', body);
    set({ busy: false });
    const { toast } = useApex.getState();
    if (!r.ok) { haptic([30, 40, 30]); toast(QERR[r.data.error ?? ''] ?? 'Something went wrong. Try again.', 'error'); return false; }
    set({ data: r.data });
    if (ok) toast(ok, 'info');
    return true;
  }

  return {
    data: null, loading: false, error: false, busy: false,

    load: async () => {
      set({ loading: true, error: false });
      const r = await api<Snapshot>('/api/quests');
      set(r.ok ? { data: r.data, loading: false } : { loading: false, error: true });
    },

    complete: async (q) => {
      const prev = get().data;
      if (!prev || q.done) return;
      set({ data: { ...prev, quests: prev.quests.map((x) => (x.id === q.id ? { ...x, done: true } : x)) } }); // optimistic
      haptic(15);
      const r = await api<Progress>('/api/quests/complete', 'POST', { questId: q.id });
      const { toast, patchHunter } = useApex.getState();
      if (!r.ok) { set({ data: prev }); return toast(QERR[r.data.error ?? ''] ?? 'Could not complete quest', 'error'); }
      const p = r.data;
      patchHunter({ xp: p.xp, need: p.need, level: p.level, points: p.points, gold: p.gold,
        stat_str: p.stat_str, stat_int: p.stat_int, stat_agi: p.stat_agi, stat_vit: p.stat_vit, stat_sen: p.stat_sen });
      toast(p.levels_gained > 0 ? `⚡ Level Up! ${p.level}` : `+${p.xp_gained} XP${p.boosted ? ' (2x!)' : ''} +${p.quest_gold}G`, 'gain');
      if (p.soldier) toast('A shadow soldier joins your army', 'gain');
    },

    randomize: async () => { await act('/api/quests/randomize', {}, '🎲 Fresh quests'); },
    reset: async () => { await act('/api/quests/reset', {}, 'Daily reset done'); },
    add: (q) => act('/api/quests', q, 'Quest added'),
    remove: async (id) => { await act('/api/quests/delete', { questId: id }, 'Quest removed'); },
  };
});
