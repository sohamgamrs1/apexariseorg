// Rule-based coach (v1). Swap coachReply's body for an LLM call later; the route stays the same.
export type Week = { journal_days: number; bosses_defeated: number; dungeons_cleared: number; gold_earned: number; army: number };
type Ctx = { streak: () => Promise<number>; week: () => Promise<Week> };

const QUOTES = [
  'Discipline is choosing what you want most over what you want now.',
  'You do not rise to your mood. You fall to your routine, so build a better routine.',
  'Small wins done daily beat big plans done never. Finish one quest right now.',
  'The Hunter who shows up tired still out-levels the one who waits to feel ready.',
  'Motivation starts the fight. Habit wins it. Start the next task in under 10 seconds.',
];
const pick = <T,>(a: T[]) => a[Math.floor(Math.random() * a.length)];

export async function coachReply(message: string, ctx: Ctx): Promise<string> {
  const m = message.toLowerCase();
  if (/motivat|inspir|quote/.test(m)) return pick(QUOTES);
  if (/analy|week|review/.test(m)) {
    const w = await ctx.week();
    const tip = w.journal_days < 4 ? 'Journaling is your weak spot. Write tonight.'
      : w.bosses_defeated < 3 ? 'Aim for a boss every other day.' : 'Solid week. Add one harder challenge next.';
    return `Last 7 days: ${w.journal_days}/7 journal days, ${w.bosses_defeated} boss${w.bosses_defeated === 1 ? '' : 'es'} defeated, ${w.dungeons_cleared} dungeon clears, ${w.gold_earned}G earned, army of ${w.army}. ${tip}`;
  }
  if (/streak/.test(m)) {
    const s = await ctx.streak();
    return s > 0 ? `Your streak is ${s} day${s === 1 ? '' : 's'}. Log today's journal entry to keep it alive.`
                 : 'No active streak right now. One journal entry today starts a new one.';
  }
  if (/habit/.test(m)) return 'Attach the new habit to one you already do, make it take under 2 minutes, and track it the same day.';
  if (/tired|lazy|give up|can'?t|burn/.test(m))
    return 'Do the smallest version of the task for 2 minutes. Starting is the hard part, and you can stop after.';
  if (/dungeon|focus/.test(m)) return 'Phone in another room, one task, one timer. Start the Dungeon and stay on that task until it ends.';
  if (/plan|today|what should/.test(m))
    return "Pick your boss for today, finish its 4 challenges, then write tomorrow's first task in your journal.";
  return 'I hear you, Hunter. Ask me to analyze your week, for motivation, or for habit and focus tips.';
}
