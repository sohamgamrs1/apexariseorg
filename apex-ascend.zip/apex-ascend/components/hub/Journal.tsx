'use client';
import { useEffect, useState } from 'react';
import { api } from '@/lib/api';
import { haptic } from '@/lib/haptics';
import { istToday, useApex } from '@/lib/store';

type Entry = { date: string; win: string; learn: string; tomorrow: string; mood: string; streak_snapshot: number };
const MOODS = ['😭', '😕', '😐', '🙂', '🔥'];
const area = 'w-full resize-none rounded-[12px] border border-white/10 bg-white/[0.04] p-3 text-[13px] outline-none focus:border-[var(--neon)]';

export function Journal() {
  const toast = useApex((s) => s.toast);
  const patchHunter = useApex((s) => s.patchHunter);
  const gold = useApex((s) => s.hunter?.gold ?? 0);
  const [entries, setEntries] = useState<Entry[] | null>(null);
  const [streak, setStreak] = useState(0);
  const [f, setF] = useState({ win: '', learn: '', tomorrow: '', mood: '' });
  const [busy, setBusy] = useState(false);

  async function load(prefill = false) {
    const r = await api<{ entries: Entry[]; current_streak: number }>('/api/journal/history?limit=5');
    if (!r.ok) return setEntries([]);
    setEntries(r.data.entries); setStreak(r.data.current_streak);
    const t = r.data.entries[0];
    if (prefill && t?.date === istToday()) setF({ win: t.win ?? '', learn: t.learn ?? '', tomorrow: t.tomorrow ?? '', mood: t.mood ?? '' });
  }
  useEffect(() => { load(true); }, []); // eslint-disable-line react-hooks/exhaustive-deps

  async function save() {
    if (!f.win.trim() && !f.learn.trim() && !f.tomorrow.trim()) return toast('Write at least one line first', 'error');
    setBusy(true);
    const r = await api<{ streak: number; best_streak: number; reward_gold: number }>('/api/journal', 'POST', f);
    setBusy(false);
    if (!r.ok) return toast('Could not save. Try again.', 'error');
    patchHunter({ streak: r.data.streak, best_streak: r.data.best_streak, gold: gold + r.data.reward_gold });
    haptic(20);
    toast(r.data.reward_gold ? `Journal saved. +${r.data.reward_gold}G · ${r.data.streak} day streak` : 'Journal updated', 'gain');
    load();
  }

  const date = new Date().toLocaleDateString('en-IN', { weekday: 'long', day: 'numeric', month: 'short', timeZone: 'Asia/Kolkata' });
  return (
    <section className="glass p-4">
      <div className="mb-3 flex items-center justify-between">
        <div><h2 className="text-[16px]">Daily Journal</h2><p id="journal-date" className="text-[11px] text-white/50">{date}</p></div>
        <span id="journal-streak" className="rounded-full bg-amber-400/10 px-3 py-1 text-[12px] font-bold text-amber-300">🔥 {streak} day streak</span>
      </div>
      <div className="space-y-2">
        {([['win', "🏆 Today's win? (What went well?)"], ['learn', '🧠 What did I learn today?'], ['tomorrow', "🎯 Tomorrow's plan? (Top 3)"]] as const).map(([k, label]) => (
          <label key={k} className="block text-[12px] text-white/70">{label}
            <textarea rows={3} maxLength={2000} value={f[k]} onChange={(e) => setF({ ...f, [k]: e.target.value })} className={`${area} mt-1`} />
          </label>
        ))}
        <div className="text-[12px] text-white/70">😊 Mood today?
          <div id="mood-selector" className="mt-1 flex gap-2" role="radiogroup" aria-label="Mood">
            {MOODS.map((m) => (
              <button key={m} role="radio" aria-checked={f.mood === m} onClick={() => setF({ ...f, mood: m })}
                className={`flex h-11 flex-1 items-center justify-center rounded-[12px] border text-[20px] ${f.mood === m ? 'border-purple-400/30 bg-purple-500/15' : 'border-white/10 bg-white/[0.04]'}`}>{m}</button>
            ))}
          </div>
        </div>
        <button disabled={busy} onClick={save} className="w-full rounded-[12px] bg-purple-500/20 py-3 text-[13px] font-bold disabled:opacity-50">💾 Save today&apos;s journal (+20G)</button>
      </div>
      <h3 className="mb-2 mt-5 text-[12px]">📚 Recent entries</h3>
      <ul id="journal-history" className="space-y-2">
        {entries === null ? <li className="text-[12px] text-white/50">Loading…</li>
          : entries.length === 0 ? <li className="text-[12px] text-white/50">No entries yet. Your first one starts the streak.</li>
          : entries.map((e) => (
            <li key={e.date} className="rounded-[12px] bg-white/[0.04] p-3">
              <div className="flex justify-between font-mono text-[11px] text-white/50"><span>{e.date}</span><span>{e.mood}</span></div>
              <p className="mt-1 line-clamp-2 text-[12px] text-white/80">{e.win || e.learn || e.tomorrow}</p>
            </li>
          ))}
      </ul>
    </section>
  );
}
