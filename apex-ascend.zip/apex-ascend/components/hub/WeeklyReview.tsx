'use client';
import { useState } from 'react';
import { api } from '@/lib/api';
import { useApex } from '@/lib/store';

type Week = { from: string; to: string; journal_days: number; bosses_defeated: number; dungeons_cleared: number; gold_earned: number; army: number; streak: number; best_streak: number; moods: string[] };

export function WeeklyReview() {
  const toast = useApex((s) => s.toast);
  const [w, setW] = useState<Week | null>(null);
  const [busy, setBusy] = useState(false);

  async function generate() {
    setBusy(true);
    const r = await api<Week>('/api/weekly-review', 'POST');
    setBusy(false);
    if (r.ok) setW(r.data); else toast('Could not generate the review', 'error');
  }
  const tiles: [string, string | number][] = w ? [
    ['Journal days', `${w.journal_days}/7`], ['Bosses defeated', w.bosses_defeated], ['Dungeons cleared', w.dungeons_cleared],
    ['Gold earned', `${w.gold_earned}G`], ['Army', w.army], ['Streak', `${w.streak} (best ${w.best_streak})`],
  ] : [];

  return (
    <section className="glass p-4">
      <div className="mb-3 flex items-center justify-between">
        <div><h2 className="text-[16px]">Weekly Review</h2><p id="weekly-review-date" className="font-mono text-[11px] text-white/50">{w ? `${w.from} → ${w.to}` : 'Last 7 days'}</p></div>
        <button disabled={busy} onClick={generate} className="rounded-full bg-purple-500/20 px-4 py-2 text-[12px] font-bold disabled:opacity-50">{busy ? 'Working…' : 'Generate'}</button>
      </div>
      {!w ? (
        <p className="py-8 text-center text-[13px] text-white/50"><span className="block text-[28px]" aria-hidden>📈</span>Tap Generate for a report on your last 7 days.</p>
      ) : (
        <div id="weekly-review-content">
          <div className="grid grid-cols-2 gap-2">
            {tiles.map(([k, v]) => <div key={k} className="rounded-[12px] bg-white/[0.04] p-3"><div className="text-[18px] font-bold">{v}</div><div className="text-[11px] text-white/50">{k}</div></div>)}
          </div>
          {w.moods.length > 0 && <p className="mt-3 text-[13px]"><span className="text-white/50">Moods: </span>{w.moods.join(' ')}</p>}
        </div>
      )}
    </section>
  );
}
