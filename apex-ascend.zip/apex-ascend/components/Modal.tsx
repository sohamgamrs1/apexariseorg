'use client';
import { useEffect, useRef } from 'react';

export function Modal({ id, title, onClose, children }: { id: string; title: string; onClose: () => void; children: React.ReactNode }) {
  const box = useRef<HTMLDivElement>(null);
  const close = useRef(onClose);
  close.current = onClose;

  useEffect(() => {
    const prev = document.activeElement as HTMLElement | null;
    box.current?.focus();
    const onKey = (e: KeyboardEvent) => { if (e.key === 'Escape') close.current(); };
    window.addEventListener('keydown', onKey);
    return () => { window.removeEventListener('keydown', onKey); prev?.focus(); };
  }, []);

  return (
    <div className="fixed inset-0 z-[60] flex items-end justify-center bg-black/70 p-3 backdrop-blur-sm sm:items-center"
      onMouseDown={(e) => { if (e.target === e.currentTarget) onClose(); }}>
      <div id={id} ref={box} role="dialog" aria-modal="true" aria-label={title} tabIndex={-1}
        className="glass max-h-[88vh] w-full max-w-[400px] overflow-y-auto p-4 outline-none" style={{ background: '#12101c' }}>
        <div className="mb-3 flex items-center justify-between">
          <h2 className="text-[16px]">{title}</h2>
          <button onClick={onClose} aria-label="Close" className="rounded-full bg-white/10 px-3 py-1 text-[12px]">✕</button>
        </div>
        {children}
      </div>
    </div>
  );
}
