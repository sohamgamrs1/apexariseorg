import { z } from 'zod';
import { callRpc } from '@/lib/rpc';

const Input = z.object({});

export const POST = (req: Request) =>
  callRpc(req, Input, 'complete_dungeon', (uid) => ({ p_user: uid }));
