'use client';
import { useState } from 'react';
import { useApex } from '@/lib/store';
import { Modal } from './Modal';

const STEPS = [
  { icon: '⚔️', title: 'Defeat one boss a day', body: "Finish a boss's 4 challenges, then claim the gold. Only one boss per day, and the Sunday Emperor appears on Sundays." },
  { icon: '🥷', title: 'Build your shadow army', body: 'Every finished quest recruits a soldier. More soldiers mean more power and a higher rank.' },
  { icon: '🔥', title: 'Keep your streak', body: 'Journal daily to grow your streak, and try the 90-minute Dungeon for a big gold reward.' },
];

export function Onboarding() {
  const onboarded = useApex((s) => s.onboarded);
  const finish = useApex((s) => s.finishOnboarding);
  const [i, setI] = useState(0);
  if (onboarded) return null;
  const s = STEPS[i]; const last = i === STEPS.length - 1;
  return (
    <Modal id="onboarding-v151" title="Welcome to Apex" onClose={finish}>
      <div className="py-4 text-center">
        <div className="text-[48px]" aria-hidden>{s.icon}</div>
        <h3 className="mt-2 text-[18px]">{s.title}</h3>
        <p className="mt-2 text-[13px] leading-relaxed text-white/70">{s.body}</p>
        <div className="mt-4 flex justify-center gap-1.5" aria-hidden>
          {STEPS.map((_, n) => <span key={n} className={`h-1.5 w-6 rounded-full ${n === i ? 'bg-[var(--neon)]' : 'bg-white/15'}`} />)}
        </div>
      </div>
      <div className="flex gap-2">
        <button onClick={finish} className="rounded-[12px] border border-white/10 px-4 py-3 text-[13px] text-white/60">Skip</button>
        <button onClick={() => (last ? finish() : setI(i + 1))} className="flex-1 rounded-[12px] bg-purple-500/25 py-3 text-[13px] font-bold">{last ? "Let's Go 🔥" : 'Next'}</button>
      </div>
    </Modal>
  );
}
