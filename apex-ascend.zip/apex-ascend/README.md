# Apex Ascend

1. `npm install`
2. Copy `.env.example` to `.env.local` and fill in the three Supabase values.
3. In the Supabase SQL editor, run `supabase/migrations/001_schema.sql`, then `002_features.sql`, then `003_original_data.sql`, `004_boss_hub.sql`, `005_avatars_backup.sql`, and `006_progression.sql` (in that order).
4. Supabase > Authentication: enable Email, and Google if you want it (add `http://localhost:3000/auth/callback` as a redirect URL).
5. `npm run dev`
