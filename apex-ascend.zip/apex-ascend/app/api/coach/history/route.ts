import { NextResponse } from 'next/server';
import { createServerClient } from '@/lib/supabase/server';
import { createAdminClient } from '@/lib/supabase/admin';

export const dynamic = 'force-dynamic';

export async function GET() {
  const { data: { user } } = await createServerClient().auth.getUser();
  if (!user) return NextResponse.json({ error: 'UNAUTHORIZED' }, { status: 401 });
  const { data } = await createAdminClient().from('coach_messages').select('role,content')
    .eq('user_id', user.id).order('created_at', { ascending: false }).limit(30);
  return NextResponse.json({ messages: (data ?? []).reverse() });
}
