'use client';
import { useEffect, useState } from 'react';
import { STATS } from '@/lib/data';
import { type NewQuest, useQuests } from '@/lib/quest-store';

const FILTERS = [['all', 'All'], ['active', 'Active'], ['done', 'Done']] as const;
const color = (k: string) => STATS.find((s) => s.k === k)?.color ?? '#fff';
const blank: NewQuest = { title: '', desc: '', stat: 'str', xp: 15, gold: 8 };
const input = 'rounded-[10px] border border-white/10 bg-white/[0.04] px-3 py-2 text-[12px] outline-none focus:border-[var(--neon)]';

export function Quests({ manage = false }: { manage?: boolean }) {
  const { data, error, busy, load, complete, randomize, reset, add, remove } = useQuests();
  const [q, setQ] = useState('');
  const [f, setF] = useState<(typeof FILTERS)[number][0]>('all');
  const [form, setForm] = useState<NewQuest | null>(null);
  useEffect(() => { load(); }, [load]);

  if (!data) return <p role="status" className="glass p-5 text-center text-[13px] text-white/60">{error ? <>Could not load quests. <button className="underline" onClick={load}>Retry</button></> : 'Loading quests…'}</p>;

  const list = data.quests.filter((x) => x.title.toLowerCase().includes(q.trim().toLowerCase()) && (f === 'all' || (f === 'done' ? x.done : !x.done)));
  const left = data.quests.filter((x) => !x.done).length;

  return (
    <section className="glass p-4" aria-labelledby="quests-h">
      <div className="mb-3 flex items-center justify-between">
        <h2 id="quests-h" className="text-[15px]">Today&apos;s Quests</h2>
        <span className="font-mono text-[12px] text-white/60">{left} left</span>
      </div>
      <div id="v151-search-bar" className="mb-3 flex gap-1.5">
        <input id="v151-search-input" type="search" value={q} onChange={(e) => setQ(e.target.value)} placeholder="🔍 Search quests..." aria-label="Search quests" className={`min-w-0 flex-1 ${input}`} />
        {FILTERS.map(([id, label]) => (
          <button key={id} aria-pressed={f === id} onClick={() => setF(id)}
            className={`rounded-[10px] border px-2.5 text-[11px] ${f === id ? 'border-[rgba(168,85,247,0.3)] bg-[rgba(168,85,247,0.15)] text-[#a78bfa]' : 'border-white/10 text-white/60'}`}>{label}</button>
        ))}
      </div>

      {manage && (
        <div className="mb-3 flex flex-wrap gap-2">
          <button disabled={busy} onClick={randomize} className="rounded-[10px] bg-purple-500/20 px-3 py-2 text-[12px] disabled:opacity-50">🎲 Randomize ({data.rolls_used}/{data.rolls_max})</button>
          <button disabled={busy} onClick={reset} className="rounded-[10px] border border-white/10 px-3 py-2 text-[12px] disabled:opacity-50">↺ Reset daily</button>
          <button onClick={() => setForm(form ? null : blank)} className="rounded-[10px] border border-white/10 px-3 py-2 text-[12px]">＋ Add quest</button>
        </div>
      )}
      {manage && form && (
        <div className="mb-3 grid grid-cols-2 gap-2 rounded-[14px] bg-white/[0.03] p-3">
          <input className={`col-span-2 ${input}`} maxLength={16} placeholder="Title (max 16)" value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} />
          <input className={`col-span-2 ${input}`} maxLength={20} placeholder="Description (max 20)" value={form.desc} onChange={(e) => setForm({ ...form, desc: e.target.value })} />
          <select className={input} value={form.stat} onChange={(e) => setForm({ ...form, stat: e.target.value as NewQuest['stat'] })} aria-label="Stat">
            {STATS.map((s) => <option key={s.k} value={s.k}>{s.label}</option>)}
          </select>
          <div className="flex gap-2">
            <input className={`w-1/2 ${input}`} type="number" min={1} max={30} value={form.xp} onChange={(e) => setForm({ ...form, xp: +e.target.value })} aria-label="XP (1-30)" />
            <input className={`w-1/2 ${input}`} type="number" min={1} max={15} value={form.gold} onChange={(e) => setForm({ ...form, gold: +e.target.value })} aria-label="Gold (1-15)" />
          </div>
          <button disabled={busy || !form.title.trim()} onClick={async () => { if (await add(form)) setForm(null); }}
            className="col-span-2 rounded-[10px] bg-purple-500/25 py-2.5 text-[12px] font-bold disabled:opacity-50">Add quest</button>
        </div>
      )}

      {list.length === 0 ? <p className="py-4 text-center text-[12px] text-white/50">No quests match.</p> : (
        <ul className="space-y-2">
          {list.map((x) => (
            <li key={x.id} className="flex gap-2">
              <button disabled={x.done} onClick={() => complete(x)}
                className={`flex min-w-0 flex-1 items-center gap-3 rounded-[14px] border px-3 py-2.5 text-left transition-colors ${x.done ? 'border-[#22c55e]/30 bg-[#22c55e]/10' : 'border-white/10 bg-white/[0.04] hover:bg-white/10'}`}>
                <span className={`flex h-5 w-5 shrink-0 items-center justify-center rounded-full border text-[11px] ${x.done ? 'border-[#22c55e] bg-[#22c55e] text-black' : 'border-white/25'}`}>{x.done ? '✓' : ''}</span>
                <span className="min-w-0 flex-1">
                  <span className={`block truncate text-[13px] font-semibold ${x.done ? 'text-emerald-200 line-through' : ''}`}>{x.title}</span>
                  <span className="block truncate text-[11px] text-white/50">{x.desc} · <b style={{ color: color(x.stat) }}>{x.stat.toUpperCase()}</b> · +{x.xp} XP · +{x.gold}G</span>
                </span>
              </button>
              {manage && <button disabled={busy} onClick={() => confirm(`Delete "${x.title}"?`) && remove(x.id)} aria-label={`Delete ${x.title}`} className="rounded-[12px] border border-white/10 px-3 text-[13px]">🗑</button>}
            </li>
          ))}
        </ul>
      )}
    </section>
  );
}
