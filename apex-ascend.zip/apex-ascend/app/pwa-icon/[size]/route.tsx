import { ImageResponse } from 'next/og';

export const runtime = 'edge';

export function GET(_: Request, { params }: { params: { size: string } }) {
  const size = params.size === '512' ? 512 : 192;
  return new ImageResponse(
    (
      <div style={{ display: 'flex', width: '100%', height: '100%', alignItems: 'center', justifyContent: 'center', color: '#fff',
        fontSize: size * 0.6, fontWeight: 800, backgroundImage: 'linear-gradient(135deg,#1a0a2e,#a855f7)' }}>A</div>
    ),
    { width: size, height: size, headers: { 'Cache-Control': 'public, max-age=86400' } },
  );
}
