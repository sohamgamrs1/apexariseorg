// Content taken from the original Apex Ascend V1.6.
export const NAV = [
  { id: 'home', label: 'Home', href: '/', icon: 'Home' },
  { id: 'quests', label: 'Quests', href: '/quests', icon: 'ScrollText' },
  { id: 'ascend', label: 'Ascend', href: '/ascend', icon: 'Mountain' },
  { id: 'focus', label: 'Focus', href: '/focus', icon: 'Target' },
  { id: 'growth', label: 'Growth', href: '/growth', icon: 'Sprout' },
  { id: 'arc', label: 'Arc', href: '/arc', icon: 'Swords' },
  { id: 'style', label: 'Style', href: '/style', icon: 'Sparkles' },
  { id: 'tracking', label: 'Track', href: '/tracking', icon: 'Activity' },
  { id: 'glory', label: 'Glory', href: '/glory', icon: 'Trophy' },
  { id: 'shop', label: 'Shop', href: '/shop', icon: 'ShoppingBag' },
  { id: 'boss', label: 'Boss', href: '/boss-realm', icon: 'Skull' },
  { id: 'hub', label: 'Hub', href: '/features-hub', icon: 'LayoutGrid' },
] as const;

export const CHALLENGES = [
  { id: 'winter', title: 'Winter Arc', icon: '❄', color: '#7dd3fc', duration: 90, difficulty: 'Hell' },
  { id: 'brahma', title: 'Brahmacharya', icon: '🧘', color: '#fbbf24', duration: 60, difficulty: 'Hard' },
  { id: 'monk', title: 'Monk Mode', icon: '⛩', color: '#a78bfa', duration: 30, difficulty: 'Medium' },
  { id: 'hard75', title: '75 Hard', icon: '🔥', color: '#f87171', duration: 75, difficulty: 'Hell' },
  { id: 'detox', title: 'Dopamine Detox', icon: '🧠', color: '#34d399', duration: 14, difficulty: 'Medium' },
  { id: '5am', title: '5 AM Club', icon: '🌅', color: '#fb923c', duration: 21, difficulty: 'Easy' },
];

export const AVATARS = [
  { id: 'lion', emoji: '🦁', name: 'Lion King', grad: 'linear-gradient(135deg,#fbbf24,#f59e0b)' },
  { id: 'wolf', emoji: '🐺', name: 'Shadow Wolf', grad: 'linear-gradient(135deg,#6b7280,#374151)' },
  { id: 'monarch', emoji: '👑', name: 'Monarch', grad: 'linear-gradient(135deg,#8b5cf6,#7c3aed)' },
  { id: 'flame', emoji: '🔥', name: 'Flame', grad: 'linear-gradient(135deg,#ef4444,#dc2626)' },
  { id: 'frost', emoji: '❄️', name: 'Frost', grad: 'linear-gradient(135deg,#38bdf8,#0ea5e9)' },
  { id: 'groom', emoji: '✨', name: 'Groomed', grad: 'linear-gradient(135deg,#4ade80,#22c55e)' },
  { id: 'berserker', emoji: '⚔️', name: 'Berserker', grad: 'linear-gradient(135deg,#991b1b,#7f1d1d)' },
  { id: 'dragon', emoji: '🐉', name: 'Dragon Emperor', grad: 'linear-gradient(135deg,#f59e0b,#d97706)' },
  { id: 'lunar', emoji: '🌙', name: 'Lunar Sage', grad: 'linear-gradient(135deg,#a78bfa,#8b5cf6)' },
  { id: 'shadow_monarch', emoji: '🌑', name: 'Shadow Monarch', grad: 'linear-gradient(135deg,#1e293b,#0f172a)' },
  { id: 'void', emoji: '👁️', name: 'Void Eye', grad: 'linear-gradient(135deg,#000000,#1f2937)' },
  { id: 'rose', emoji: '🌹', name: 'Rose Sorceress', grad: 'linear-gradient(135deg,#ec4899,#be185d)' },
];

export type ShopItem = { id: string; icon: string; name: string; cost: number; desc: string; avatarId?: string; soon?: boolean };
export const SHOP: ShopItem[] = [
  { id: 'shield', icon: '🛡️', name: 'Shield', cost: 100, desc: 'Saves 1 missed day, weekly protection', soon: true },
  { id: 'freeze', icon: '❄️', name: 'Streak Freeze', cost: 150, desc: 'Freeze streak for 1 day without shield', soon: true },
  { id: 'theme', icon: '🎨', name: 'Theme Unlock', cost: 50, desc: 'Unlock 1 random premium theme', soon: true },
  { id: 'extraRandom', icon: '🎲', name: 'Extra Random', cost: 30, desc: 'Extra random refresh beyond daily limit' },
  { id: 'xpBoost', icon: '✨', name: 'XP Boost 2x', cost: 80, desc: '2x XP for next 24 hours' },
  { id: 'nameToken', icon: '🔄', name: 'Name Change Token', cost: 40, desc: 'Required to change hunter name' },
  { id: 'avatar_berserker', icon: '⚔️', name: 'Berserker Avatar', cost: 200, desc: 'Unlock Berserker avatar', avatarId: 'berserker' },
  { id: 'avatar_lunar', icon: '🌙', name: 'Lunar Sage', cost: 300, desc: 'Unlock Lunar Sage avatar', avatarId: 'lunar' },
  { id: 'avatar_rose', icon: '🌹', name: 'Rose Sorceress', cost: 400, desc: 'Unlock Rose Sorceress avatar', avatarId: 'rose' },
  { id: 'avatar_dragon', icon: '🐉', name: 'Dragon Emperor', cost: 500, desc: 'Unlock Dragon Emperor avatar', avatarId: 'dragon' },
  { id: 'avatar_void', icon: '👁️', name: 'Void Eye', cost: 800, desc: 'Unlock Void Eye avatar', avatarId: 'void' },
  { id: 'avatar_shadow', icon: '🌑', name: 'Shadow Monarch', cost: 1000, desc: 'Unlock Shadow Monarch avatar', avatarId: 'shadow_monarch' },
];

export const STATS = [
  { k: 'str', label: 'STR', color: '#f87171' }, { k: 'int', label: 'INT', color: '#38bdf8' }, { k: 'agi', label: 'AGI', color: '#4ade80' },
  { k: 'vit', label: 'VIT', color: '#facc15' }, { k: 'sen', label: 'SEN', color: '#a78bfa' },
] as const;
