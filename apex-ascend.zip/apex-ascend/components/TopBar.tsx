'use client';
import { useApex } from '@/lib/store';

export function TopBar() {
  const hunter = useApex((s) => s.hunter);
  const sound = useApex((s) => s.sound);
  const toggleSound = useApex((s) => s.toggleSound);
  return (
    <header className="flex items-center justify-between">
      <div className="flex items-baseline gap-2">
        <h1 className="text-[20px]">Apex</h1>
        {hunter && <span className="font-mono text-[11px] text-white/60">LVL {hunter.level}</span>}
      </div>
      <div className="flex items-center gap-2">
        <button onClick={toggleSound} aria-pressed={sound} aria-label="Sound effects" className="rounded-full border border-white/10 px-2.5 py-1 text-[13px]">{sound ? '🔊' : '🔇'}</button>
        {hunter && (
          <div id="topbar-streak-counter" aria-label={`${hunter.streak} day streak`}
            className="rounded-full border border-orange-400/30 px-3 py-1 text-[13px] font-bold text-amber-300"
            style={{ background: 'linear-gradient(135deg, rgba(251,146,60,0.18), rgba(251,191,36,0.12))' }}>
            🔥 {hunter.streak}
          </div>
        )}
      </div>
    </header>
  );
}
