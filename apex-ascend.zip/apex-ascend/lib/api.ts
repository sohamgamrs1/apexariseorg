export type ApiResult<T> = { ok: boolean; status: number; data: T & { error?: string } };

export async function api<T = Record<string, never>>(path: string, method: 'GET' | 'POST' = 'GET', json?: unknown): Promise<ApiResult<T>> {
  try {
    const res = await fetch(path, {
      method, cache: 'no-store',
      headers: json ? { 'Content-Type': 'application/json' } : undefined,
      body: json ? JSON.stringify(json) : undefined,
    });
    return { ok: res.ok, status: res.status, data: (await res.json().catch(() => ({}))) as ApiResult<T>['data'] };
  } catch { return { ok: false, status: 0, data: {} as ApiResult<T>['data'] }; }
}

export const ERRORS: Record<string, string> = {
  DAILY_LIMIT: 'Daily limit reached. One boss per day.',
  INCOMPLETE: 'Finish all 4 challenges first.',
  NOT_SUNDAY: 'The Sunday Emperor only appears on Sunday.',
  UNAUTHORIZED: 'Session expired. Sign in again.',
};
