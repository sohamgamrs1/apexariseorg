'use client';
import { useEffect, useState } from 'react';
import { api } from '@/lib/api';

type Army = { count: number; power: number; rank: string; next_rank_in: number | null; soldiers: { index: number; habit: string | null }[] };

export function ShadowArmy() {
  const [a, setA] = useState<Army | null>(null);
  const [err, setErr] = useState(false);
  useEffect(() => { api<Army>('/api/army').then((r) => (r.ok ? setA(r.data) : setErr(true))); }, []);

  if (err) return <p className="glass p-5 text-center text-[13px]">Could not load your army.</p>;
  if (!a) return <p role="status" className="glass p-5 text-center text-[13px] text-white/60">Loading army…</p>;
  const next = a.next_rank_in == null ? 'Max rank' : `${a.rank === 'Recruit' ? 'Warrior' : 'Monarch'} in ${a.next_rank_in}`;
  const habit = new Map(a.soldiers.map((s) => [s.index, s.habit]));

  return (
    <section className="glass p-4">
      <div className="mb-3 flex items-center justify-between">
        <div><h2 className="text-[16px]">Shadow Army</h2><p className="text-[11px] text-white/50">Habit → soldiers · power = discipline</p></div>
        <div className="text-right"><div id="army-count" className="text-[24px] font-bold">{a.count}</div><div className="font-mono text-[9px] text-white/50">SOLDIERS</div></div>
      </div>
      <div className="mb-4 grid grid-cols-3 gap-2 text-center">
        {[['ARMY POWER', a.power], ['RANK', a.rank], ['NEXT', next]].map(([k, v]) => (
          <div key={k} className="rounded-[12px] bg-white/[0.04] px-1 py-2"><div className="font-mono text-[9px] text-white/50">{k}</div><div className="text-[13px] font-bold">{v}</div></div>
        ))}
      </div>
      <div id="soldier-grid" className="grid grid-cols-5 gap-2" role="list" aria-label="Shadow soldiers">
        {Array.from({ length: 25 }, (_, i) => {
          const on = habit.has(i);
          return (
            <div key={i} role="listitem" title={on ? habit.get(i) ?? 'Soldier' : 'Locked'} aria-label={on ? `Soldier ${i + 1}: ${habit.get(i) ?? 'unlocked'}` : `Soldier ${i + 1}: locked`}
              className={`flex aspect-square items-center justify-center rounded-[12px] border text-[20px] ${on ? 'border-purple-400/30 bg-purple-500/15 shadow-[0_0_10px_rgba(168,85,247,0.35)]' : 'border-white/5 bg-white/[0.03] opacity-40'}`}>
              {on ? '🥷' : '🔒'}
            </div>
          );
        })}
      </div>
      <div className="mt-4 rounded-[12px] bg-white/[0.03] p-3 text-[11px] leading-relaxed text-white/60">
        Finish a quest to recruit a soldier (up to 8 a day). Power = soldiers × 10. Recruit 0-5 · Warrior 6-15 · Monarch 16-25.
      </div>
    </section>
  );
}
