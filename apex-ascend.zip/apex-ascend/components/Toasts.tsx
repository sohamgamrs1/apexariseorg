'use client';
import { AnimatePresence, motion } from 'framer-motion';
import { useApex } from '@/lib/store';

const tone = { gain: 'border-[#22c55e]/40 text-emerald-200', error: 'border-red-400/70 text-red-200', info: 'border-purple-400/30 text-purple-200' };

export function Toasts() {
  const toasts = useApex((s) => s.toasts);
  return (
    <div aria-live="polite" className="pointer-events-none fixed inset-x-0 top-3 z-[70] mx-auto flex max-w-[390px] flex-col gap-2 px-3">
      <AnimatePresence>
        {toasts.map((t) => (
          <motion.div key={t.id} initial={{ opacity: 0, y: -12 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}
            className={`glass border px-4 py-2.5 text-[13px] ${tone[t.tone]}`}>{t.text}</motion.div>
        ))}
      </AnimatePresence>
    </div>
  );
}
