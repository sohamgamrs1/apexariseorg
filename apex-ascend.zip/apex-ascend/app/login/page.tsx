'use client';
import { useState } from 'react';
import { createClient } from '@/lib/supabase/client';

export default function Login() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [msg, setMsg] = useState('');
  const [busy, setBusy] = useState(false);
  const supabase = createClient();

  async function submit(mode: 'in' | 'up') {
    setBusy(true); setMsg('');
    const { error } = mode === 'in'
      ? await supabase.auth.signInWithPassword({ email, password })
      : await supabase.auth.signUp({ email, password, options: { emailRedirectTo: `${location.origin}/auth/callback` } });
    setBusy(false);
    if (error) return setMsg(error.message);
    if (mode === 'up') return setMsg('Check your email to confirm your account.');
    location.href = '/';
  }
  const google = () => supabase.auth.signInWithOAuth({ provider: 'google', options: { redirectTo: `${location.origin}/auth/callback` } });
  const field = 'w-full rounded-[12px] border border-white/10 bg-white/[0.04] px-3 py-3 text-[14px] outline-none focus:border-[var(--neon)]';

  return (
    <main className="mx-auto flex min-h-screen max-w-[380px] flex-col justify-center gap-3 px-4">
      <h1 className="mb-2 text-[28px]">Apex Ascend</h1>
      <input className={field} type="email" placeholder="Email" autoComplete="email" value={email} onChange={(e) => setEmail(e.target.value)} />
      <input className={field} type="password" placeholder="Password" autoComplete="current-password" value={password} onChange={(e) => setPassword(e.target.value)} />
      <button disabled={busy} onClick={() => submit('in')} className="rounded-[12px] bg-purple-500/20 py-3 text-[14px] font-bold disabled:opacity-50">Sign in</button>
      <button disabled={busy} onClick={() => submit('up')} className="rounded-[12px] border border-white/10 py-3 text-[14px] disabled:opacity-50">Create account</button>
      <button onClick={google} className="rounded-[12px] border border-white/10 py-3 text-[14px]">Continue with Google</button>
      {msg && <p role="status" className="text-[13px] text-amber-300">{msg}</p>}
    </main>
  );
}
