'use client';
import { useRef, useState } from 'react';
import { motion } from 'framer-motion';
import { AVATARS, STATS } from '@/lib/data';
import { exportBackup, importBackup } from '@/lib/backup';
import { useApex } from '@/lib/store';
import { AvatarModal } from './AvatarModal';
import { ShareModal } from './ShareModal';

export function HunterCard() {
  const h = useApex((s) => s.hunter);
  const toast = useApex((s) => s.toast);
  const rename = useApex((s) => s.rename);
  const tokens = useApex((s) => s.owned.nameToken ?? 0);
  const [modal, setModal] = useState<'avatar' | 'share' | null>(null);
  const file = useRef<HTMLInputElement>(null);
  if (!h) return null;

  const av = AVATARS.find((a) => a.id === h.avatar_id) ?? AVATARS[0];
  const pct = Math.min(100, (h.xp / h.need) * 100);
  const boosted = !!h.xp_boost_until && new Date(h.xp_boost_until) > new Date();
  const val = { str: h.stat_str, int: h.stat_int, agi: h.stat_agi, vit: h.stat_vit, sen: h.stat_sen };
  const btn = 'flex-1 rounded-[12px] border border-white/10 bg-white/[0.04] py-2 text-[12px]';

  async function backup() { try { await exportBackup(); toast('Backup downloaded', 'gain'); } catch { toast('Backup failed. Try again.', 'error'); } }
  async function restore(f?: File) {
    if (!f) return;
    try { const n = await importBackup(f); toast(`Restored ${n} new journal entries. Reloading…`, 'gain'); setTimeout(() => location.reload(), 900); }
    catch { toast('That file is not a valid Apex backup.', 'error'); }
    if (file.current) file.current.value = '';
  }
  function edit() {
    const n = prompt(`New hunter name (uses 1 Name Token, you have ${tokens})`, h!.name)?.trim();
    if (n && n !== h!.name) rename(n);
  }

  return (
    <section id="boss-home-card" className="glass p-4" aria-label="Hunter">
      <div className="flex items-center gap-3">
        <button onClick={() => setModal('avatar')} aria-label="Change avatar"
          className="flex h-16 w-16 shrink-0 items-center justify-center overflow-hidden rounded-full text-[30px] ring-1 ring-[var(--neon)]" style={{ background: av.grad }}>
          {h.custom_avatar_url
            // eslint-disable-next-line @next/next/no-img-element
            ? <img src={h.custom_avatar_url} alt="" className="h-full w-full object-cover" />
            : <span aria-hidden>{av.emoji}</span>}
        </button>
        <div className="min-w-0 flex-1">
          <div className="flex items-center gap-2">
            <h2 className="truncate text-[20px]">{h.name}</h2>
            <button onClick={edit} aria-label="Edit name" className="rounded-full bg-white/10 px-2 py-0.5 text-[10px]">EDIT</button>
            {boosted && <span className="rounded-full bg-amber-400/15 px-2 py-0.5 text-[10px] text-amber-300">✨ 2x XP</span>}
          </div>
          <p className="font-mono text-[11px] text-white/60">LVL {h.level} · XP {h.xp}/{h.need} · {h.points} pts</p>
          <div className="mt-1.5 h-1.5 overflow-hidden rounded-full bg-white/10" role="progressbar" aria-valuenow={Math.round(pct)} aria-valuemin={0} aria-valuemax={100}>
            <motion.div className="h-full rounded-full bg-[var(--neon)]" initial={false} animate={{ width: `${pct}%` }} />
          </div>
        </div>
      </div>
      <div className="mt-3 grid grid-cols-5 gap-1.5 text-center">
        {STATS.map((s) => (
          <div key={s.k} className="rounded-[12px] bg-white/[0.04] py-1.5">
            <div className="text-[16px] font-bold" style={{ color: s.color }}>{val[s.k]}</div>
            <div className="font-mono text-[9px] text-white/50">{s.label}</div>
          </div>
        ))}
      </div>
      <div className="mt-2 grid grid-cols-2 gap-2 text-center">
        <div className="rounded-[14px] bg-white/[0.04] py-2"><div className="text-[18px] font-bold">🔥 {h.best_streak}</div><div className="text-[10px] text-white/60">Best streak</div></div>
        <div className="rounded-[14px] bg-amber-400/10 py-2"><div className="text-[18px] font-bold text-amber-300">🪙 {h.gold}</div><div className="text-[10px] text-white/60">Gold</div></div>
      </div>
      <div className="mt-3 flex gap-2">
        <button className={btn} onClick={() => setModal('share')}>📤 Share</button>
        <button className={btn} onClick={backup}>💾 Backup</button>
        <button className={btn} onClick={() => file.current?.click()}>📥 Restore</button>
        <input ref={file} type="file" accept="application/json,.json" hidden onChange={(e) => restore(e.target.files?.[0])} />
      </div>
      {modal === 'avatar' && <AvatarModal onClose={() => setModal(null)} />}
      {modal === 'share' && <ShareModal onClose={() => setModal(null)} />}
    </section>
  );
}
