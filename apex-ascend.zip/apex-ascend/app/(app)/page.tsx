import { Arcs } from '@/components/Arcs';
import { HunterCard } from '@/components/HunterCard';
import { Onboarding } from '@/components/Onboarding';
import { Quests } from '@/components/Quests';
import { Shop } from '@/components/Shop';

export default function Home() {
  return (
    <div className="space-y-4">
      <HunterCard />
      <Quests />
      <Arcs />
      <Shop />
      <Onboarding />
    </div>
  );
}
