'use client';
import { useState } from 'react';
import { Modal } from './Modal';

export function ShareModal({ onClose }: { onClose: () => void }) {
  const [src] = useState(() => `/api/share-card/generate?t=${Date.now()}`);
  const [state, setState] = useState<'loading' | 'ready' | 'error'>('loading');
  const canShare = typeof navigator !== 'undefined' && typeof navigator.share === 'function';

  async function share() {
    try {
      const blob = await (await fetch(src)).blob();
      const f = new File([blob], 'apex-ascend-card.png', { type: 'image/png' });
      if (navigator.canShare?.({ files: [f] })) await navigator.share({ files: [f], title: 'Apex Ascend' });
    } catch { /* cancelled */ }
  }

  return (
    <Modal id="share-modal-v151" title="Share Card" onClose={onClose}>
      {state === 'loading' && <p role="status" className="py-10 text-center text-[13px] text-white/60">Rendering your card…</p>}
      {state === 'error' && <p className="py-10 text-center text-[13px] text-red-300">Could not render the card. Try again.</p>}
      {/* eslint-disable-next-line @next/next/no-img-element */}
      <img src={src} alt="Your Apex Ascend hunter card" onLoad={() => setState('ready')} onError={() => setState('error')}
        className={`w-full rounded-[20px] ${state === 'ready' ? '' : 'hidden'}`} style={{ aspectRatio: '1080 / 1920' }} />
      {state === 'ready' && (
        <div className="mt-3 flex gap-2">
          <a href={src} download="apex-ascend-card.png" className="flex-1 rounded-[12px] bg-purple-500/25 py-3 text-center text-[13px] font-bold">⬇ Download</a>
          {canShare && <button onClick={share} className="flex-1 rounded-[12px] border border-white/10 py-3 text-[13px]">📤 Share</button>}
        </div>
      )}
    </Modal>
  );
}
