import { z } from 'zod';
import { callRpc } from '@/lib/rpc';

const text = z.string().max(2000).nullish();
const Entry = z.object({ date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/), win: text, learn: text, tomorrow: text, mood: z.string().max(16).nullish() });
const Body = z.object({ journal: z.array(Entry).max(400) });

export const POST = (req: Request) => callRpc(req, Body, 'import_journal', (uid, b) => ({ p_user: uid, p_entries: b.journal }));
