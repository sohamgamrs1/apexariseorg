import { api } from './api';

const LOCAL_KEYS = ['apex-ascend-v1', 'apex-boss-v1'];

export async function exportBackup() {
  const r = await api<Record<string, unknown>>('/api/export');
  if (!r.ok) throw new Error('export failed');
  const local: Record<string, string> = {};
  for (const k of LOCAL_KEYS) { const v = localStorage.getItem(k); if (v) local[k] = v; }
  const blob = new Blob([JSON.stringify({ ...r.data, local }, null, 2)], { type: 'application/json' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = `apex-ascend-backup-${new Date().toISOString().slice(0, 10)}.json`;
  a.click();
  setTimeout(() => URL.revokeObjectURL(a.href), 1000);
}

/** Restores journal entries (server-side) and this device's local progress. Gold, XP and inventory are never restored. */
export async function importBackup(file: File): Promise<number> {
  if (file.size > 3_000_000) throw new Error('file too large');
  const j = JSON.parse(await file.text());
  if (j?.app !== 'apex-ascend') throw new Error('not an Apex backup');
  const journal = Array.isArray(j.journal_entries) ? j.journal_entries.slice(0, 400) : [];
  const r = await api<{ imported: number }>('/api/import', 'POST', { journal });
  if (!r.ok) throw new Error('import failed');
  for (const k of LOCAL_KEYS) {
    const v = j.local?.[k];
    if (typeof v === 'string') { try { JSON.parse(v); localStorage.setItem(k, v); } catch { /* skip corrupt entry */ } }
  }
  return r.data.imported;
}
