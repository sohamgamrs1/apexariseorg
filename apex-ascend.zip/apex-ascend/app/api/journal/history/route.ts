import { z } from 'zod';
import { callRpc } from '@/lib/rpc';

const Input = z.object({ limit: z.coerce.number().int().min(1).max(30).default(5) });

export const GET = (req: Request) =>
  callRpc(req, Input, 'journal_history', (uid, i) => ({ p_user: uid, p_limit: i.limit }));
