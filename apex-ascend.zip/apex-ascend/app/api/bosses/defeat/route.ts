import { z } from 'zod';
import { callRpc } from '@/lib/rpc';

const Body = z.object({ bossId: z.string().min(1), challengesDone: z.array(z.string()).max(4) });

export const POST = (req: Request) =>
  callRpc(req, Body, 'defeat_boss', (uid, b) => ({ p_user: uid, p_boss: b.bossId, p_done: b.challengesDone }));
