'use client';
import { SHOP } from '@/lib/data';
import { useApex } from '@/lib/store';

export function Shop() {
  const gold = useApex((s) => s.hunter?.gold ?? 0);
  const owned = useApex((s) => s.owned);
  const buy = useApex((s) => s.buy);
  return (
    <section className="glass p-4" aria-labelledby="shop-h">
      <h2 id="shop-h" className="mb-3 text-[15px]">Gold Shop V2 🛒</h2>
      <ul className="grid grid-cols-2 gap-2">
        {SHOP.map((i) => {
          const qty = owned[i.id] ?? 0;
          const locked = !!i.avatarId && qty > 0;
          const off = locked || !!i.soon;
          return (
            <li key={i.id} className="flex flex-col rounded-[14px] border border-white/10 bg-white/[0.04] p-3">
              <div className="flex items-center justify-between"><span className="text-[22px]" aria-hidden>{i.icon}</span>{!i.avatarId && !i.soon && qty > 0 && <span className="font-mono text-[11px] text-white/60">x{qty}</span>}</div>
              <div className="mt-1 text-[13px] font-bold leading-tight">{i.name}</div>
              <p className="mt-0.5 flex-1 text-[11px] leading-snug text-white/60">{i.desc}</p>
              <button disabled={off} onClick={() => buy(i.id)}
                className={`mt-2 rounded-[10px] py-1.5 text-[12px] font-bold transition-colors disabled:opacity-50 ${off || gold < i.cost ? 'bg-white/5 text-white/60' : 'bg-amber-400/15 text-amber-300 hover:bg-amber-400/25'}`}>
                {locked ? 'Owned' : i.soon ? 'Coming soon' : `🪙 ${i.cost}`}
              </button>
            </li>
          );
        })}
      </ul>
    </section>
  );
}
