-- Phase 4: Boss Realm + Features Hub. Aligns data/rules with the original V1.6. Run after 003.
alter table challenger_bosses add column if not exists is_weekly boolean not null default false;
alter table challenger_bosses add column if not exists reward_title text;
alter table challenger_bosses add column if not exists sort int not null default 0;

insert into challenger_bosses (id,name,emoji,title,color,bg,border,reward_text,gold_reward,reward_title,is_weekly,sort) values
 ('sunday_emperor','Sunday Emperor','👑','Weekly Emperor • Sunday Only','#fbbf24','rgba(251,191,36,0.15)','rgba(251,191,36,0.3)','1000G + Emperor Title',1000,'Emperor Title',true,0),
 ('iron_titan','Iron Titan','🤖','Steel Colossus','#fbbf24','rgba(251,191,36,0.15)','rgba(251,191,36,0.3)','300G + Iron Will',300,'Iron Will',false,1),
 ('frost_monarch','Frost Monarch','❄️','Ice Monarch','#7dd3fc','rgba(125,211,252,0.15)','rgba(125,211,252,0.3)','350G + Frost Title',350,'Frost Title',false,2),
 ('shadow_dragon','Shadow Dragon','🐉','Ancient Beast','#a78bfa','rgba(167,139,250,0.15)','rgba(167,139,250,0.3)','400G + Dragon Slayer',400,'Dragon Slayer',false,3),
 ('demon_lord','Demon Lord','👹','Lord of Darkness','#f87171','rgba(248,113,113,0.15)','rgba(248,113,113,0.3)','500G + Demon Slayer',500,'Demon Slayer',false,4),
 ('void_walker','Void Walker','👁️','Abyss Watcher','#34d399','rgba(52,211,153,0.15)','rgba(52,211,153,0.3)','300G + Void Walker',300,'Void Walker',false,5)
on conflict (id) do update set name=excluded.name, emoji=excluded.emoji, title=excluded.title, color=excluded.color,
  bg=excluded.bg, border=excluded.border, reward_text=excluded.reward_text, gold_reward=excluded.gold_reward,
  reward_title=excluded.reward_title, is_weekly=excluded.is_weekly, sort=excluded.sort;

delete from boss_challenges;
insert into boss_challenges (id,boss_id,title,icon) values
 ('w1','sunday_emperor','100 Pushups','💪'),('w2','sunday_emperor','100 Squats','🦵'),('w3','sunday_emperor','5km Run','🏃'),('w4','sunday_emperor','Meditate 30min','🧘'),
 ('it1','iron_titan','50 Pushups','💪'),('it2','iron_titan','70 Squats','🦵'),('it3','iron_titan','30 Sit Ups','🔥'),('it4','iron_titan','25 Pullups','🏋️'),
 ('fm1','frost_monarch','5km Run','🏃'),('fm2','frost_monarch','100 Burpees','💥'),('fm3','frost_monarch','60 Lunges','🦵'),('fm4','frost_monarch','2min Plank','🧘'),
 ('sd1','shadow_dragon','30 Pullups','🏋️'),('sd2','shadow_dragon','100 Pushups','💪'),('sd3','shadow_dragon','50 Leg Raises','🦵'),('sd4','shadow_dragon','40 Dips','🔥'),
 ('dl1','demon_lord','100 Squats','🦵'),('dl2','demon_lord','50 Sit Ups','🔥'),('dl3','demon_lord','30 Pushups','💪'),('dl4','demon_lord','10km Walk','🚶'),
 ('vw1','void_walker','Meditate 20min','🧘'),('vw2','void_walker','Read 30 Pages','📚'),('vw3','void_walker','Journal 500 Words','✍️'),('vw4','void_walker','No Phone 4hrs','📵');

-- Boss defeat: now also handles the Sunday-only weekly boss, titles, and the original's glory-log wording.
create or replace function defeat_boss(p_user uuid, p_boss text, p_done text[]) returns jsonb
language plpgsql security definer set search_path = public as $$
declare
  v_boss challenger_bosses%rowtype; v_today date := ist_today();
  v_total int; v_valid int; v_xp int; v_h hunters%rowtype;
begin
  select * into v_boss from challenger_bosses where id = p_boss;
  if not found then raise exception 'UNKNOWN_BOSS'; end if;
  if v_boss.is_weekly and extract(dow from v_today) <> 0 then raise exception 'NOT_SUNDAY'; end if;

  select count(*), coalesce(sum(xp),0) into v_total, v_xp from boss_challenges where boss_id = p_boss;
  select count(distinct c) into v_valid from unnest(p_done) c
    where c in (select id from boss_challenges where boss_id = p_boss);
  if v_valid < v_total then raise exception 'INCOMPLETE'; end if;

  insert into daily_boss_limit (user_id, date, count) values (p_user, v_today, 1)
    on conflict (user_id, date) do nothing;
  if not found then raise exception 'DAILY_LIMIT'; end if;

  update hunters set gold = gold + v_boss.gold_reward, xp = xp + v_xp, level = 1 + (xp + v_xp) / 100,
    last_active = v_today,
    titles = case when v_boss.reward_title is null or v_boss.reward_title = any(titles) then titles
                  else array_append(titles, v_boss.reward_title) end
  where id = p_user returning * into v_h;
  if not found then raise exception 'NO_HUNTER'; end if;

  insert into glory_logs (user_id, challenge_id, glory_title, challenge_title, icon, color, xp, gold, date)
  values (p_user, p_boss, 'Boss Slayer: ' || v_boss.name, v_boss.name, v_boss.emoji, v_boss.color, v_xp, v_boss.gold_reward, v_today);

  if v_boss.is_weekly then
    insert into weekly_boss_state (user_id, week_start, hp, max_hp, is_defeated, defeated_at)
    values (p_user, v_today, 0, 200, true, now())
    on conflict (user_id, week_start) do update set hp = 0, is_defeated = true, defeated_at = now();
  end if;

  return jsonb_build_object('defeated', true, 'boss', v_boss.name, 'reward_gold', v_boss.gold_reward, 'reward_xp', v_xp,
    'title', v_boss.reward_title, 'gold', v_h.gold, 'xp', v_h.xp, 'level', v_h.level);
end $$;

create or replace function boss_status(p_user uuid) returns jsonb
language plpgsql security definer set search_path = public as $$
declare v_today date := ist_today(); v_dow int := extract(dow from ist_today())::int;
begin
  return jsonb_build_object(
    'today', v_today, 'is_sunday', v_dow = 0,
    'next_sunday', v_today + case when v_dow = 0 then 7 else 7 - v_dow end,
    'daily_available', not exists (select 1 from daily_boss_limit d where d.user_id = p_user and d.date = v_today and d.count >= 1),
    'claimed_today', (select coalesce(jsonb_agg(g.challenge_id), '[]'::jsonb) from glory_logs g
                      where g.user_id = p_user and g.date = v_today and g.challenge_id <> 'dungeon'),
    'weekly_defeated', exists (select 1 from weekly_boss_state w where w.user_id = p_user and w.week_start = v_today - v_dow and w.is_defeated),
    'bosses', (select coalesce(jsonb_agg(o.j order by o.sort), '[]'::jsonb) from (
      select cb.sort, jsonb_build_object('id', cb.id, 'name', cb.name, 'emoji', cb.emoji, 'title', cb.title,
        'color', cb.color, 'bg', cb.bg, 'border', cb.border, 'reward_text', cb.reward_text,
        'gold_reward', cb.gold_reward, 'is_weekly', cb.is_weekly,
        'challenges', (select jsonb_agg(jsonb_build_object('id', c.id, 'title', c.title, 'icon', c.icon) order by c.id)
                       from boss_challenges c where c.boss_id = cb.id)) as j
      from challenger_bosses cb) o));
end $$;

-- Dungeon: stats for the idle view, and the original's -50G penalty for giving up (never below 0).
create or replace function dungeon_state(p_user uuid) returns jsonb
language plpgsql security definer set search_path = public as $$
declare r dungeon_runs%rowtype; v_stats jsonb;
begin
  select jsonb_build_object('completed', count(*) filter (where status = 'completed'),
    'failed', count(*) filter (where status = 'failed'),
    'best_minutes', round(min(best_time) filter (where status = 'completed') / 60.0)::int)
  into v_stats from dungeon_runs where user_id = p_user;

  select * into r from dungeon_runs where user_id = p_user and status = 'active';
  if not found then return jsonb_build_object('status', 'idle') || v_stats; end if;
  return jsonb_build_object('status', 'active', 'run_id', r.id, 'start_time', r.start_time,
    'duration', r.duration, 'server_now', now(),
    'remaining', greatest(0, ceil(extract(epoch from (r.start_time + make_interval(mins => r.duration) - now())))::int)) || v_stats;
end $$;

create or replace function exit_dungeon(p_user uuid) returns jsonb
language plpgsql security definer set search_path = public as $$
declare r dungeon_runs%rowtype; v_el int; v_pen int; v_gold int;
begin
  select * into r from dungeon_runs where user_id = p_user and status = 'active' for update;
  if not found then raise exception 'NO_ACTIVE_RUN'; end if;
  v_el := extract(epoch from (now() - r.start_time))::int;
  if v_el >= r.duration * 60 - 5 then raise exception 'ALREADY_FINISHED'; end if;
  update dungeon_runs set status = 'failed', end_time = now(), best_time = v_el where id = r.id;
  select least(50, gold) into v_pen from hunters where id = p_user for update;
  update hunters set gold = gold - coalesce(v_pen, 0) where id = p_user returning gold into v_gold;
  return jsonb_build_object('failed', true, 'elapsed', v_el, 'penalty', coalesce(v_pen, 0), 'gold', v_gold);
end $$;

-- Journal: +20G on the first save of each day (original behaviour).
create or replace function save_journal(p_user uuid, p_win text, p_learn text, p_tomorrow text, p_mood text)
returns jsonb language plpgsql security definer set search_path = public as $$
declare v_today date := ist_today(); v_prev journal_entries%rowtype; v_streak int; v_new boolean; v_best int; v_gold int;
begin
  perform 1 from hunters where id = p_user for update;
  if not found then raise exception 'NO_HUNTER'; end if;

  select * into v_prev from journal_entries where user_id = p_user and date = v_today;
  if found then
    v_new := false; v_streak := coalesce(v_prev.streak_snapshot, 1);
  else
    v_new := true;
    select * into v_prev from journal_entries where user_id = p_user and date = v_today - 1;
    v_streak := case when found then coalesce(v_prev.streak_snapshot, 0) + 1 else 1 end;
  end if;

  insert into journal_entries (user_id, date, win, learn, tomorrow, mood, streak_snapshot)
  values (p_user, v_today, p_win, p_learn, p_tomorrow, p_mood, v_streak)
  on conflict (user_id, date) do update
    set win = excluded.win, learn = excluded.learn, tomorrow = excluded.tomorrow, mood = excluded.mood;

  update hunters set streak = v_streak, best_streak = greatest(best_streak, v_streak), last_active = v_today,
    gold = gold + case when v_new then 20 else 0 end
  where id = p_user returning best_streak, gold into v_best, v_gold;

  return jsonb_build_object('streak', v_streak, 'best_streak', v_best, 'new_day', v_new,
    'reward_gold', case when v_new then 20 else 0 end, 'gold', v_gold);
end $$;

-- Shadow Army: original rule is "1 quest = 1 soldier"; cap raised to 8/day (= quests per day) to bound abuse.
create or replace function unlock_soldier(p_user uuid, p_habit text) returns jsonb
language plpgsql security definer set search_path = public as $$
declare v_cap constant int := 8; v_idx int;
begin
  perform 1 from hunters where id = p_user for update;
  if not found then raise exception 'NO_HUNTER'; end if;
  if (select count(*) from shadow_army where user_id = p_user and unlocked
        and (unlocked_at at time zone 'Asia/Kolkata')::date = ist_today()) >= v_cap
    then raise exception 'ARMY_DAILY_CAP'; end if;
  select min(i) into v_idx from generate_series(0, 24) i
   where not exists (select 1 from shadow_army s where s.user_id = p_user and s.soldier_index = i and s.unlocked);
  if v_idx is null then raise exception 'ARMY_FULL'; end if;
  insert into shadow_army (user_id, soldier_index, unlocked, unlocked_at, habit_name)
  values (p_user, v_idx, true, now(), left(p_habit, 80))
  on conflict (user_id, soldier_index) do update set unlocked = true, unlocked_at = now(), habit_name = excluded.habit_name;
  return army_status(p_user) || jsonb_build_object('unlocked_index', v_idx);
end $$;

-- Weekly review: rolling 7 days ending today, saved per day.
create unique index if not exists weekly_reviews_user_week on weekly_reviews (user_id, week_start);
create or replace function generate_weekly_review(p_user uuid) returns jsonb
language plpgsql security definer set search_path = public as $$
declare v_to date := ist_today(); v_from date := ist_today() - 6; v_c jsonb;
begin
  select jsonb_build_object('from', v_from, 'to', v_to,
    'journal_days', (select count(*) from journal_entries where user_id = p_user and date between v_from and v_to),
    'bosses_defeated', (select count(*) from glory_logs where user_id = p_user and date between v_from and v_to and challenge_id <> 'dungeon'),
    'dungeons_cleared', (select count(*) from glory_logs where user_id = p_user and date between v_from and v_to and challenge_id = 'dungeon'),
    'gold_earned', (select coalesce(sum(gold), 0) from glory_logs where user_id = p_user and date between v_from and v_to),
    'army', (select count(*) from shadow_army where user_id = p_user and unlocked),
    'streak', (journal_history(p_user, 1) ->> 'current_streak')::int,
    'best_streak', (select best_streak from hunters where id = p_user),
    'moods', (select coalesce(jsonb_agg(mood order by date), '[]'::jsonb) from journal_entries
              where user_id = p_user and date between v_from and v_to and mood <> ''))
  into v_c;
  insert into weekly_reviews (user_id, week_start, content) values (p_user, v_from, v_c)
    on conflict (user_id, week_start) do update set content = excluded.content, created_at = now();
  return v_c;
end $$;

revoke all on function boss_status(uuid), generate_weekly_review(uuid) from public, anon, authenticated;
grant execute on function boss_status(uuid), generate_weekly_review(uuid) to service_role;
