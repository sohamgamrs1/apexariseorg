'use client';
import { useEffect } from 'react';
import Link from 'next/link';
import { MotionConfig } from 'framer-motion';
import { BossCard } from '@/components/boss/BossCard';
import { useBoss } from '@/lib/boss-store';

export default function BossRealm() {
  const { status, loading, error, load, reset } = useBoss();
  useEffect(() => { load(); }, [load]);

  if (!status) {
    return (
      <div role="status" className="glass p-6 text-center text-[13px] text-white/60">
        {error ? <>Could not load bosses. <button className="underline" onClick={load}>Retry</button></> : 'Loading bosses…'}
      </div>
    );
  }
  const weekly = status.bosses.find((b) => b.is_weekly);
  const challengers = status.bosses.filter((b) => !b.is_weekly);

  return (
    <MotionConfig reducedMotion="user">
      <div id="boss-realm-page">
        <div className="mb-5 flex items-center justify-between">
          <Link href="/" className="rounded-full border border-white/15 bg-white/10 px-3.5 py-2 text-[12px]">← Back</Link>
          <span className="rounded-full border border-amber-400/20 bg-amber-400/15 px-2 py-0.5 text-[10px] text-amber-300">1 BOSS / DAY</span>
        </div>
        <div className="mb-6 text-center">
          <div className="mb-2 text-[36px]" aria-hidden>👹⚔️🐉</div>
          <h1 className="text-[26px]">Boss Realm</h1>
          <p className="mt-1.5 font-mono text-[11px] text-white/50">Weekly: Sunday only · Challengers: 1 boss/day</p>
        </div>

        {weekly && (status.is_sunday ? <BossCard boss={weekly} /> : (
          <div id="weekly-not-sunday" className="glass mb-3 p-5 text-center">
            <div className="mb-2 text-[32px]" aria-hidden>⏳👑</div>
            <h3 className="text-[15px] text-white/70">Weekly Boss - Sunday Only</h3>
            <p className="mt-1.5 text-[12px] text-white/50">The Sunday Emperor appears every Sunday at 12 AM IST and disappears on Monday.</p>
            <p className="mt-3 rounded-[8px] bg-white/[0.03] p-2 font-mono text-[11px] text-white/50">Next appearance: {status.next_sunday}</p>
          </div>
        ))}

        <div className="mb-3.5 mt-6 flex items-center justify-between">
          <h2 className="text-[16px]">⚔️ Challenger Bosses</h2>
          <div className="flex items-center gap-1.5">
            <span id="daily-boss-status" className={`rounded-full border px-2 py-1 font-mono text-[10px] ${status.daily_available ? 'border-[#22c55e]/20 bg-[#22c55e]/15 text-[#22c55e]' : 'border-red-500/20 bg-red-500/15 text-red-300'}`}>
              {status.daily_available ? 'AVAILABLE - 1/DAY' : 'LOCKED - TOMORROW'}
            </span>
            <button id="reset-bosses" onClick={() => confirm("Reset today's boss progress? The daily limit stays.") && reset()}
              className="rounded-full border border-white/10 bg-white/[0.08] px-2.5 py-1 text-[10px] text-white/60">Reset</button>
          </div>
        </div>

        <div id="challenger-container">
          {loading && !challengers.length ? <p className="text-center text-[13px] text-white/60">Loading bosses…</p>
            : challengers.map((b) => <BossCard key={b.id} boss={b} />)}
        </div>
        <p className="mt-6 rounded-[12px] border border-dashed border-white/10 bg-white/[0.02] p-4 text-center font-mono text-[11px] text-white/40">
          🔒 1 boss/day. After a defeat, the other bosses stay locked until tomorrow.
        </p>
      </div>
    </MotionConfig>
  );
}
