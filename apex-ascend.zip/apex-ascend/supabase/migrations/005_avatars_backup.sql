-- Phase 5: avatar equip, journal import, avatar storage bucket. Run after 004.
create or replace function select_avatar(p_user uuid, p_avatar text) returns jsonb
language plpgsql security definer set search_path = public as $$
declare v_av avatars%rowtype;
begin
  select * into v_av from avatars where id = p_avatar;
  if not found then raise exception 'UNKNOWN_AVATAR'; end if;
  if v_av.price > 0 and not exists (
    select 1 from user_inventory ui join gold_shop_items g on g.id = ui.item_id
    where ui.user_id = p_user and g.avatar_id = p_avatar) then raise exception 'AVATAR_LOCKED'; end if;
  update hunters set avatar_id = p_avatar, custom_avatar_url = null where id = p_user;
  if not found then raise exception 'NO_HUNTER'; end if;
  return jsonb_build_object('avatar_id', p_avatar);
end $$;

-- Backup restore. Journal only: gold, XP and inventory are never importable (server-authoritative economy).
-- Existing entries are kept; streak snapshots are recomputed from consecutive days.
create or replace function import_journal(p_user uuid, p_entries jsonb) returns jsonb
language plpgsql security definer set search_path = public as $$
declare v_n int; v_cur int; v_best int;
begin
  perform 1 from hunters where id = p_user for update;
  if not found then raise exception 'NO_HUNTER'; end if;

  insert into journal_entries (user_id, date, win, learn, tomorrow, mood, streak_snapshot)
  select p_user, (e ->> 'date')::date, left(e ->> 'win', 2000), left(e ->> 'learn', 2000),
         left(e ->> 'tomorrow', 2000), left(e ->> 'mood', 16), 1
  from jsonb_array_elements(p_entries) e
  where (e ->> 'date')::date between date '2020-01-01' and ist_today()
  on conflict (user_id, date) do nothing;
  get diagnostics v_n = row_count;

  with ranked as (
    select id, date, date - (row_number() over (order by date))::int as grp from journal_entries where user_id = p_user
  ), numbered as (
    select id, row_number() over (partition by grp order by date) as n from ranked
  )
  update journal_entries j set streak_snapshot = numbered.n from numbered where j.id = numbered.id;

  select coalesce(max(streak_snapshot), 0) into v_best from journal_entries where user_id = p_user;
  select coalesce((select streak_snapshot from journal_entries where user_id = p_user and date >= ist_today() - 1
                   order by date desc limit 1), 0) into v_cur;
  update hunters set streak = v_cur, best_streak = greatest(best_streak, v_best) where id = p_user;
  return jsonb_build_object('imported', v_n, 'streak', v_cur);
end $$;

revoke all on function select_avatar(uuid,text), import_journal(uuid,jsonb) from public, anon, authenticated;
grant execute on function select_avatar(uuid,text), import_journal(uuid,jsonb) to service_role;

-- Custom avatars: public bucket, each user writes only inside their own folder (<uid>/avatar.png), 1 MB cap.
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('avatars', 'avatars', true, 1048576, array['image/png'])
on conflict (id) do nothing;
drop policy if exists "avatars read own" on storage.objects;
drop policy if exists "avatars insert own" on storage.objects;
drop policy if exists "avatars update own" on storage.objects;
drop policy if exists "avatars delete own" on storage.objects;
create policy "avatars read own" on storage.objects for select to authenticated
  using (bucket_id = 'avatars' and (storage.foldername(name))[1] = auth.uid()::text);
create policy "avatars insert own" on storage.objects for insert to authenticated
  with check (bucket_id = 'avatars' and (storage.foldername(name))[1] = auth.uid()::text);
create policy "avatars update own" on storage.objects for update to authenticated
  using (bucket_id = 'avatars' and (storage.foldername(name))[1] = auth.uid()::text)
  with check (bucket_id = 'avatars' and (storage.foldername(name))[1] = auth.uid()::text);
create policy "avatars delete own" on storage.objects for delete to authenticated
  using (bucket_id = 'avatars' and (storage.foldername(name))[1] = auth.uid()::text);
