'use client';
import { useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { useApex } from '@/lib/store';
import { BottomNav } from './BottomNav';
import { TopBar } from './TopBar';
import { Toasts } from './Toasts';

export function AppShell({ children }: { children: React.ReactNode }) {
  const status = useApex((s) => s.status);
  const hydrate = useApex((s) => s.hydrate);
  const router = useRouter();

  useEffect(() => { hydrate(); }, [hydrate]);
  useEffect(() => { if (status === 'unauth') router.replace('/login'); }, [status, router]);

  return (
    <div className="mx-auto max-w-[430px] px-3 pb-[110px] pt-3">
      <TopBar />
      <main className="mt-3">
        {status === 'ready' ? children : status === 'error' ? (
          <div className="glass p-6 text-center text-[13px]">
            Could not load your hunter. <button className="underline" onClick={hydrate}>Retry</button>
          </div>
        ) : (
          <div role="status" className="glass p-6 text-center text-[13px] text-white/60">Loading hunter…</div>
        )}
      </main>
      <BottomNav />
      <Toasts />
    </div>
  );
}
