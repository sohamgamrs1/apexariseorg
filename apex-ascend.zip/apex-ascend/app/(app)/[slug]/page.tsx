// Placeholder for screens built in later phases (Boss Realm and Features Hub replace their own slugs).
export default function Soon({ params }: { params: { slug: string } }) {
  return (
    <div className="glass p-6 text-center">
      <h2 className="text-[18px]">{params.slug.replace(/-/g, ' ')}</h2>
      <p className="mt-2 text-[13px] text-white/60">This screen is built in a later phase.</p>
    </div>
  );
}
