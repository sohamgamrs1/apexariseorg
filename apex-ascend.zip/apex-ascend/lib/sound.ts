// Tiny WebAudio blips, no asset files. Always gated by the sound toggle in the store.
let ctx: AudioContext | null = null;

export function sfx(kind: 'gain' | 'error' | 'info') {
  try {
    const AC = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    ctx ??= new AC();
    const t = ctx.currentTime;
    const [a, b] = kind === 'gain' ? [660, 880] : kind === 'error' ? [220, 160] : [440, 520];
    const o = ctx.createOscillator(); const g = ctx.createGain();
    o.type = 'sine'; o.frequency.setValueAtTime(a, t); o.frequency.setValueAtTime(b, t + 0.09);
    g.gain.setValueAtTime(0.08, t); g.gain.exponentialRampToValueAtTime(0.0001, t + 0.22);
    o.connect(g).connect(ctx.destination); o.start(t); o.stop(t + 0.22);
  } catch { /* audio unavailable */ }
}
