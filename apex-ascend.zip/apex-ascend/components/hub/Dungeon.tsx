'use client';
import { useCallback, useEffect, useState } from 'react';
import { api } from '@/lib/api';
import { haptic } from '@/lib/haptics';
import { useApex } from '@/lib/store';

type DS = { status: 'idle' | 'active'; remaining?: number; duration?: number; completed: number; failed: number; best_minutes: number | null };
const mmss = (s: number) => `${String(Math.floor(s / 60)).padStart(2, '0')}:${String(s % 60).padStart(2, '0')}`;

export function Dungeon() {
  const toast = useApex((s) => s.toast);
  const patchHunter = useApex((s) => s.patchHunter);
  const [ds, setDs] = useState<DS | null>(null);
  const [endAt, setEndAt] = useState(0);
  const [now, setNow] = useState(Date.now());
  const [busy, setBusy] = useState(false);

  const load = useCallback(async () => {
    const r = await api<DS>('/api/dungeon');
    if (r.ok) { setNow(Date.now()); setEndAt(Date.now() + (r.data.remaining ?? 0) * 1000); setDs(r.data); }
  }, []);
  useEffect(() => { load(); }, [load]);

  const active = ds?.status === 'active';
  useEffect(() => {
    if (!active) return;
    const t = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(t);
  }, [active]);

  const total = (ds?.duration ?? 90) * 60;
  const left = active ? Math.max(0, Math.ceil((endAt - now) / 1000)) : 0;
  const finished = active && left === 0;

  // Warn before closing mid-run. The server clock decides the outcome, so a refresh just resumes the timer.
  useEffect(() => {
    if (!active || finished) return;
    const h = (e: BeforeUnloadEvent) => { e.preventDefault(); e.returnValue = ''; };
    window.addEventListener('beforeunload', h);
    return () => window.removeEventListener('beforeunload', h);
  }, [active, finished]);

  async function start() {
    setBusy(true);
    const r = await api('/api/dungeon/start', 'POST');
    setBusy(false);
    if (!r.ok) return toast('Could not start the dungeon', 'error');
    haptic(30); await load();
  }
  async function giveUp() {
    if (!confirm('Give up? The run fails and you lose 50G.')) return;
    setBusy(true);
    const r = await api<{ penalty: number; gold: number }>('/api/dungeon/exit', 'POST');
    setBusy(false);
    if (r.ok) { patchHunter({ gold: r.data.gold }); haptic([60, 40, 60]); toast(`Dungeon failed. -${r.data.penalty}G`, 'error'); }
    else if (r.data.error === 'ALREADY_FINISHED') toast('Timer finished. Claim your reward.', 'info');
    await load();
  }
  async function claim() {
    setBusy(true);
    const r = await api<{ gold: number }>('/api/dungeon/complete', 'POST');
    setBusy(false);
    if (r.ok) { patchHunter({ gold: r.data.gold }); haptic([20, 40, 20, 40]); toast('Dungeon cleared! +500G · Dungeon Master', 'gain'); }
    else toast('Not ready yet', 'error');
    await load();
  }

  if (!ds) return <p role="status" className="glass p-5 text-center text-[13px] text-white/60">Loading dungeon…</p>;

  return (
    <section className="glass p-4 text-center">
      <div className="text-[40px]" aria-hidden>🏰</div>
      <h2 className="text-[20px]">Dungeon Mode</h2>
      <p className="mb-4 text-[11px] text-white/50">90 min hardcore · stay on task</p>

      {!active && (
        <div>
          <div className="mb-3 rounded-[12px] border border-red-500/20 bg-red-500/10 p-3 text-left text-[12px] leading-relaxed text-red-200">
            <strong>Rules</strong><br />• 90 minutes of continuous focus<br />• Giving up costs 50G<br />• Clear it for +500G and the Dungeon Master title
          </div>
          <button disabled={busy} onClick={start} className="w-full rounded-[14px] bg-gradient-to-br from-red-500 to-orange-500 py-3.5 text-[14px] font-bold text-white disabled:opacity-50">🔥 ENTER DUNGEON (90M)</button>
          <p className="mt-3 font-mono text-[11px] text-white/50">Completed: {ds.completed} · Failed: {ds.failed} · Best: {ds.best_minutes ? `${ds.best_minutes}m` : '--'}</p>
        </div>
      )}

      {active && !finished && (
        <div>
          <p className="text-[12px] font-bold text-red-300">🔴 DUNGEON ACTIVE</p>
          <div id="dungeon-timer" role="timer" className="my-2 font-mono text-[56px] font-bold leading-none text-red-500">{mmss(left)}</div>
          <p className="mb-2 text-[11px] text-white/50">Progress: {Math.round(((total - left) / total) * 100)}% · Elapsed: {Math.floor((total - left) / 60)}m</p>
          <div className="mb-4 h-2 overflow-hidden rounded-full bg-white/10"><div className="h-full rounded-full bg-red-500" style={{ width: `${((total - left) / total) * 100}%` }} /></div>
          <button disabled={busy} onClick={giveUp} className="w-full rounded-[12px] border border-red-500/30 bg-red-500/10 py-2.5 text-[12px] text-red-200 disabled:opacity-50">❌ Give up (-50G)</button>
        </div>
      )}

      {finished && (
        <div>
          <div className="text-[40px]" aria-hidden>🏆</div>
          <h3 className="text-[18px]">Dungeon cleared!</h3>
          <p className="mb-3 text-[12px] text-white/60">+500G and the Dungeon Master title</p>
          <button disabled={busy} onClick={claim} className="w-full rounded-[14px] bg-gradient-to-br from-amber-400 to-orange-500 py-3.5 text-[14px] font-bold text-black disabled:opacity-50">🎁 Claim reward</button>
        </div>
      )}
    </section>
  );
}
