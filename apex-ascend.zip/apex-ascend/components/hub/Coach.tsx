'use client';
import { useEffect, useRef, useState } from 'react';
import { api } from '@/lib/api';
import { haptic } from '@/lib/haptics';

type Msg = { role: 'user' | 'ai'; content: string };
const WELCOME: Msg = { role: 'ai', content: "Hey Hunter! I'm your AI Coach. I use your streak, journal, and boss data to give advice. Ask me anything or tap a quick action." };
const QUICK = [['📊 Analyze my week', 'Analyze my week'], ['🔥 Motivate me', 'Motivate me'], ['💡 Habit tips', 'Habit tips'], ['🎯 Focus tips', 'Focus tips']];

export function Coach() {
  const [msgs, setMsgs] = useState<Msg[]>([WELCOME]);
  const [text, setText] = useState('');
  const [busy, setBusy] = useState(false);
  const end = useRef<HTMLDivElement>(null);

  useEffect(() => { api<{ messages: Msg[] }>('/api/coach/history').then((r) => r.ok && r.data.messages.length && setMsgs([WELCOME, ...r.data.messages])); }, []);
  useEffect(() => { end.current?.scrollIntoView({ block: 'end' }); }, [msgs]);

  async function send(content: string) {
    const c = content.trim();
    if (!c || busy) return;
    setText(''); setBusy(true); haptic(8);
    setMsgs((m) => [...m, { role: 'user', content: c }]);
    const r = await api<{ reply: string }>('/api/coach/message', 'POST', { content: c });
    setBusy(false);
    setMsgs((m) => [...m, { role: 'ai', content: r.ok ? r.data.reply : 'I could not reach the server. Try again in a moment.' }]);
  }

  return (
    <section className="glass flex flex-col p-4">
      <div className="mb-3 flex items-center gap-3">
        <div className="text-[28px]" aria-hidden>🤖</div>
        <div className="flex-1"><h2 className="text-[16px]">AI Coach Apex</h2><p className="text-[11px] text-emerald-300">● Online</p></div>
        <span className="rounded-full bg-purple-500/20 px-2 py-0.5 text-[9px] font-bold text-purple-200">BETA</span>
      </div>
      <div id="coach-chat" className="max-h-[320px] space-y-2 overflow-y-auto" aria-live="polite">
        {msgs.map((m, i) => (
          <div key={i} className={`coach-bubble ${m.role} max-w-[88%] whitespace-pre-wrap rounded-[16px] px-3 py-2 text-[13px] leading-snug ${m.role === 'ai' ? 'bg-white/[0.06]' : 'ml-auto bg-purple-500/25'}`}>{m.content}</div>
        ))}
        {busy && <div className="max-w-[60%] rounded-[16px] bg-white/[0.06] px-3 py-2 text-[13px] text-white/50">Thinking…</div>}
        <div ref={end} />
      </div>
      <div id="coach-quick-actions" className="no-scrollbar my-3 flex gap-2 overflow-x-auto">
        {QUICK.map(([label, msg]) => <button key={msg} onClick={() => send(msg)} className="shrink-0 rounded-full border border-white/10 bg-white/[0.04] px-3 py-1.5 text-[12px]">{label}</button>)}
      </div>
      <div className="flex gap-2">
        <input id="coach-input" value={text} maxLength={500} placeholder="Ask AI Coach anything…" onChange={(e) => setText(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && send(text)}
          className="min-w-0 flex-1 rounded-[12px] border border-white/10 bg-white/[0.04] px-3 py-2.5 text-[13px] outline-none focus:border-[var(--neon)]" />
        <button disabled={busy || !text.trim()} onClick={() => send(text)} aria-label="Send" className="w-11 rounded-[12px] bg-purple-500/25 text-[16px] disabled:opacity-40">➤</button>
      </div>
    </section>
  );
}
