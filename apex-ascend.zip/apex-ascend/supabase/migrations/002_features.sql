-- Phase 2: Dungeon, Journal streak, Shadow Army. Run after 001_schema.sql.
alter table hunters add column if not exists titles text[] not null default '{}';
create unique index if not exists one_active_dungeon on dungeon_runs (user_id) where status = 'active';

-- ---------- Dungeon (server clock is the source of truth) ----------
create or replace function dungeon_state(p_user uuid) returns jsonb
language plpgsql security definer set search_path = public as $$
declare r dungeon_runs%rowtype;
begin
  select * into r from dungeon_runs where user_id = p_user and status = 'active';
  if not found then return jsonb_build_object('status', 'idle'); end if;
  return jsonb_build_object('status', 'active', 'run_id', r.id, 'start_time', r.start_time,
    'duration', r.duration, 'server_now', now(),
    'remaining', greatest(0, ceil(extract(epoch from (r.start_time + make_interval(mins => r.duration) - now())))::int));
end $$;

-- Idempotent: starting while a run is active just resumes it.
create or replace function start_dungeon(p_user uuid) returns jsonb
language plpgsql security definer set search_path = public as $$
begin
  perform 1 from hunters where id = p_user for update;
  if not found then raise exception 'NO_HUNTER'; end if;
  if not exists (select 1 from dungeon_runs where user_id = p_user and status = 'active') then
    insert into dungeon_runs (user_id, start_time, status) values (p_user, now(), 'active');
  end if;
  return dungeon_state(p_user);
end $$;

-- best_time = seconds actually spent in the run. 5 s slack covers network latency.
create or replace function complete_dungeon(p_user uuid) returns jsonb
language plpgsql security definer set search_path = public as $$
declare r dungeon_runs%rowtype; v_el int; v_gold int;
begin
  select * into r from dungeon_runs where user_id = p_user and status = 'active' for update;
  if not found then raise exception 'NO_ACTIVE_RUN'; end if;
  v_el := extract(epoch from (now() - r.start_time))::int;
  if v_el < r.duration * 60 - 5 then raise exception 'TOO_EARLY'; end if;

  update dungeon_runs set status = 'completed', end_time = now(), best_time = v_el where id = r.id;
  update hunters set gold = gold + 500, last_active = ist_today(),
    titles = case when 'Dungeon Master' = any(titles) then titles else array_append(titles, 'Dungeon Master') end
  where id = p_user returning gold into v_gold;
  insert into glory_logs (user_id, challenge_id, glory_title, challenge_title, icon, color, xp, gold, date, duration)
  values (p_user, 'dungeon', 'Dungeon Master', '90-Min Dungeon', '🏰', '#ef4444', 0, 500, ist_today(), r.duration);

  return jsonb_build_object('completed', true, 'reward_gold', 500, 'gold', v_gold, 'title', 'Dungeon Master');
end $$;

-- Leaving early fails the run. If the timer already finished, the run is kept so it can be claimed.
create or replace function exit_dungeon(p_user uuid) returns jsonb
language plpgsql security definer set search_path = public as $$
declare r dungeon_runs%rowtype; v_el int;
begin
  select * into r from dungeon_runs where user_id = p_user and status = 'active' for update;
  if not found then raise exception 'NO_ACTIVE_RUN'; end if;
  v_el := extract(epoch from (now() - r.start_time))::int;
  if v_el >= r.duration * 60 - 5 then raise exception 'ALREADY_FINISHED'; end if;
  update dungeon_runs set status = 'failed', end_time = now(), best_time = v_el where id = r.id;
  return jsonb_build_object('failed', true, 'elapsed', v_el);
end $$;

-- ---------- Journal + streak ----------
-- First save of the day: yesterday's entry exists -> streak + 1, otherwise reset to 1. Re-saving today keeps it.
create or replace function save_journal(p_user uuid, p_win text, p_learn text, p_tomorrow text, p_mood text)
returns jsonb language plpgsql security definer set search_path = public as $$
declare v_today date := ist_today(); v_prev journal_entries%rowtype; v_streak int; v_new boolean; v_best int;
begin
  perform 1 from hunters where id = p_user for update;   -- serialises concurrent saves
  if not found then raise exception 'NO_HUNTER'; end if;

  select * into v_prev from journal_entries where user_id = p_user and date = v_today;
  if found then
    v_new := false; v_streak := coalesce(v_prev.streak_snapshot, 1);
  else
    v_new := true;
    select * into v_prev from journal_entries where user_id = p_user and date = v_today - 1;
    v_streak := case when found then coalesce(v_prev.streak_snapshot, 0) + 1 else 1 end;
  end if;

  insert into journal_entries (user_id, date, win, learn, tomorrow, mood, streak_snapshot)
  values (p_user, v_today, p_win, p_learn, p_tomorrow, p_mood, v_streak)
  on conflict (user_id, date) do update
    set win = excluded.win, learn = excluded.learn, tomorrow = excluded.tomorrow, mood = excluded.mood;

  update hunters set streak = v_streak, best_streak = greatest(best_streak, v_streak), last_active = v_today
  where id = p_user returning best_streak into v_best;

  return jsonb_build_object('streak', v_streak, 'best_streak', v_best, 'new_day', v_new);
end $$;

-- current_streak is 0 if the last entry is older than yesterday (hunters.streak alone can go stale).
create or replace function journal_history(p_user uuid, p_limit int default 5) returns jsonb
language plpgsql security definer set search_path = public as $$
declare v_last journal_entries%rowtype; v_cur int;
begin
  select * into v_last from journal_entries where user_id = p_user order by date desc limit 1;
  v_cur := case when found and v_last.date >= ist_today() - 1 then coalesce(v_last.streak_snapshot, 0) else 0 end;
  return jsonb_build_object('current_streak', v_cur, 'entries', (
    select coalesce(jsonb_agg(to_jsonb(j) order by j.date desc), '[]'::jsonb)
    from (select date, win, learn, tomorrow, mood, streak_snapshot from journal_entries
          where user_id = p_user order by date desc limit least(greatest(p_limit, 1), 30)) j));
end $$;

-- ---------- Shadow Army ----------
create or replace function army_rank(n int) returns text language sql immutable as
$$ select case when n <= 5 then 'Recruit' when n <= 15 then 'Warrior' else 'Monarch' end $$;

create or replace function army_status(p_user uuid) returns jsonb
language plpgsql security definer set search_path = public as $$
declare v_n int;
begin
  select count(*) into v_n from shadow_army where user_id = p_user and unlocked;
  return jsonb_build_object('count', v_n, 'power', v_n * 10, 'rank', army_rank(v_n),
    'next_rank_in', case when v_n <= 5 then 6 - v_n when v_n <= 15 then 16 - v_n end,
    'soldiers', (select coalesce(jsonb_agg(jsonb_build_object('index', soldier_index, 'habit', habit_name)
                 order by soldier_index), '[]'::jsonb) from shadow_army where user_id = p_user and unlocked));
end $$;

-- Assumption: 1 new soldier per IST day (anti-farming, since habits are tracked client-side). Change v_cap to loosen.
create or replace function unlock_soldier(p_user uuid, p_habit text) returns jsonb
language plpgsql security definer set search_path = public as $$
declare v_cap constant int := 1; v_idx int;
begin
  perform 1 from hunters where id = p_user for update;
  if not found then raise exception 'NO_HUNTER'; end if;
  if (select count(*) from shadow_army where user_id = p_user and unlocked
        and (unlocked_at at time zone 'Asia/Kolkata')::date = ist_today()) >= v_cap
    then raise exception 'ARMY_DAILY_CAP'; end if;

  select min(i) into v_idx from generate_series(0, 24) i
   where not exists (select 1 from shadow_army s where s.user_id = p_user and s.soldier_index = i and s.unlocked);
  if v_idx is null then raise exception 'ARMY_FULL'; end if;

  insert into shadow_army (user_id, soldier_index, unlocked, unlocked_at, habit_name)
  values (p_user, v_idx, true, now(), left(p_habit, 80))
  on conflict (user_id, soldier_index) do update set unlocked = true, unlocked_at = now(), habit_name = excluded.habit_name;

  return army_status(p_user) || jsonb_build_object('unlocked_index', v_idx);
end $$;

revoke all on function dungeon_state(uuid), start_dungeon(uuid), complete_dungeon(uuid), exit_dungeon(uuid),
  save_journal(uuid,text,text,text,text), journal_history(uuid,int), army_status(uuid), unlock_soldier(uuid,text)
  from public, anon, authenticated;
grant execute on function dungeon_state(uuid), start_dungeon(uuid), complete_dungeon(uuid), exit_dungeon(uuid),
  save_journal(uuid,text,text,text,text), journal_history(uuid,int), army_status(uuid), unlock_soldier(uuid,text)
  to service_role;
