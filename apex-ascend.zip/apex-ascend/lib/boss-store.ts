'use client';
import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { api, ERRORS } from './api';
import { haptic } from './haptics';
import { istToday, useApex } from './store';

export type Challenge = { id: string; title: string; icon: string };
export type Boss = {
  id: string; name: string; emoji: string; title: string; color: string; bg: string; border: string;
  reward_text: string; gold_reward: number; is_weekly: boolean; challenges: Challenge[];
};
export type BossStatus = {
  today: string; is_sunday: boolean; next_sunday: string; daily_available: boolean;
  claimed_today: string[]; weekly_defeated: boolean; bosses: Boss[];
};

interface State {
  status: BossStatus | null; loading: boolean; error: boolean; claiming: string | null;
  day: string; done: string[]; // today's checked challenge ids (honor system; the claim is validated server-side)
  load: () => Promise<void>;
  toggle: (boss: Boss, challengeId: string) => void;
  reset: () => void;
  defeat: (boss: Boss) => Promise<void>;
}

export const useBoss = create<State>()(
  persist(
    (set, get) => ({
      status: null, loading: false, error: false, claiming: null, day: istToday(), done: [],

      load: async () => {
        set({ loading: true, error: false });
        const r = await api<BossStatus>('/api/bosses');
        if (!r.ok) return set({ loading: false, error: true });
        set((s) => ({ status: r.data, loading: false, ...(s.day !== r.data.today ? { day: r.data.today, done: [] } : {}) }));
      },

      toggle: (boss, cid) => {
        const st = get().status;
        if (!st || st.claimed_today.includes(boss.id) || (boss.is_weekly && st.weekly_defeated)) return;
        const today = istToday();
        const done = get().day === today ? get().done : [];
        const on = done.includes(cid);
        if (!on && !st.daily_available) {
          haptic([30, 40, 30]);
          return useApex.getState().toast('Locked. You defeated a boss today, the rest unlock tomorrow.', 'error');
        }
        haptic(10);
        set({ day: today, done: on ? done.filter((x) => x !== cid) : [...done, cid] });
      },

      reset: () => { set({ done: [], day: istToday() }); useApex.getState().toast('Boss progress reset. Daily limit stays.', 'info'); },

      defeat: async (boss) => {
        if (get().claiming) return;
        set({ claiming: boss.id });
        const ids = get().done.filter((id) => boss.challenges.some((c) => c.id === id));
        const r = await api<{ gold: number; xp: number; need: number; points: number; level: number; reward_gold: number }>('/api/bosses/defeat', 'POST', { bossId: boss.id, challengesDone: ids });
        const { toast, patchHunter } = useApex.getState();
        if (r.ok) {
          patchHunter({ gold: r.data.gold, xp: r.data.xp, need: r.data.need, points: r.data.points, level: r.data.level }); // server balance is the truth
          haptic([20, 40, 20]);
          toast(`${boss.emoji} ${boss.name} defeated! +${r.data.reward_gold}G`, 'gain');
        } else {
          haptic([30, 40, 30]);
          toast(ERRORS[r.data.error ?? ''] ?? 'Could not claim. Try again.', 'error');
        }
        set({ claiming: null });
        await get().load(); // re-sync daily lock / claimed state
      },
    }),
    { name: 'apex-boss-v1', partialize: (s) => ({ day: s.day, done: s.done }) },
  ),
);
