'use client';
import { useRef, useState } from 'react';
import { AVATARS, SHOP } from '@/lib/data';
import { api } from '@/lib/api';
import { haptic } from '@/lib/haptics';
import { useApex } from '@/lib/store';
import { createClient } from '@/lib/supabase/client';
import { Modal } from './Modal';

export function AvatarModal({ onClose }: { onClose: () => void }) {
  const hunter = useApex((s) => s.hunter)!;
  const owned = useApex((s) => s.owned);
  const buy = useApex((s) => s.buy);
  const patchHunter = useApex((s) => s.patchHunter);
  const toast = useApex((s) => s.toast);
  const [busy, setBusy] = useState<string | null>(null);
  const file = useRef<HTMLInputElement>(null);

  const item = (id: string) => SHOP.find((i) => i.avatarId === id);
  const unlocked = (id: string) => { const it = item(id); return !it || !!owned[it.id]; };
  const custom = hunter.custom_avatar_url;

  async function pick(id: string) {
    const it = item(id);
    if (!unlocked(id) && it) {
      if (!confirm(`Unlock ${it.name} for ${it.cost} gold?`)) return;
      await buy(it.id);
      if (!useApex.getState().owned[it.id]) return; // purchase failed; buy() already toasted
    }
    setBusy(id);
    const r = await api('/api/avatar/select', 'POST', { avatarId: id });
    setBusy(null);
    if (!r.ok) return toast('Could not equip that avatar', 'error');
    patchHunter({ avatar_id: id, custom_avatar_url: null });
    haptic(15); toast('Avatar equipped', 'gain'); onClose();
  }

  async function upload(f: File) {
    setBusy('custom');
    try {
      const bmp = await createImageBitmap(f);
      const s = Math.min(bmp.width, bmp.height);
      const c = document.createElement('canvas'); c.width = c.height = 256;
      c.getContext('2d')!.drawImage(bmp, (bmp.width - s) / 2, (bmp.height - s) / 2, s, s, 0, 0, 256, 256);
      const blob = await new Promise<Blob>((res, rej) => c.toBlob((b) => (b ? res(b) : rej(new Error('encode'))), 'image/png'));
      const sb = createClient();
      const { data: { user } } = await sb.auth.getUser();
      if (!user) throw new Error('auth');
      const up = await sb.storage.from('avatars').upload(`${user.id}/avatar.png`, blob, { upsert: true, contentType: 'image/png' });
      if (up.error) throw up.error;
      const r = await api<{ custom_avatar_url: string }>('/api/avatar/select', 'POST', { custom: true });
      if (!r.ok) throw new Error('select');
      patchHunter({ custom_avatar_url: r.data.custom_avatar_url });
      haptic(15); toast('Custom avatar set', 'gain'); onClose();
    } catch { toast('Upload failed. Try a different image.', 'error'); }
    setBusy(null);
  }

  const tile = (on: boolean) => `relative flex aspect-square flex-col items-center justify-center rounded-[16px] border text-center transition-all ${on ? 'border-[var(--neon)] shadow-[0_0_16px_rgba(168,85,247,0.5)]' : 'border-white/10'}`;
  return (
    <Modal id="apex-avatar-modal" title="Choose Avatar" onClose={onClose}>
      <div id="apex-avatar-grid" className="grid grid-cols-3 gap-2.5">
        <button className={`${tile(!!custom)} bg-white/[0.04] text-[11px]`} aria-pressed={!!custom} disabled={busy !== null} onClick={() => file.current?.click()}>
          {custom
            // eslint-disable-next-line @next/next/no-img-element
            ? <img src={custom} alt="" className="h-full w-full rounded-[15px] object-cover" />
            : <><span className="text-[26px]" aria-hidden>📷</span>Upload</>}
        </button>
        <input ref={file} type="file" accept="image/*" hidden onChange={(e) => { const f = e.target.files?.[0]; if (f) upload(f); e.target.value = ''; }} />
        {AVATARS.map((a) => {
          const open = unlocked(a.id);
          const it = item(a.id);
          return (
            <button key={a.id} className={tile(!custom && hunter.avatar_id === a.id)} style={{ background: a.grad }} disabled={busy !== null}
              aria-pressed={!custom && hunter.avatar_id === a.id} aria-label={`${a.name}${open ? '' : `, locked, ${it?.cost} gold`}`} onClick={() => pick(a.id)}>
              <span className={`text-[32px] ${open ? '' : 'opacity-40'}`} aria-hidden>{a.emoji}</span>
              <span className="mt-0.5 text-[10px] font-bold drop-shadow">{a.name}</span>
              {!open && <span className="absolute inset-x-1 bottom-1 rounded-full bg-black/70 py-0.5 text-[10px] text-amber-300">🔒 {it?.cost}G</span>}
            </button>
          );
        })}
      </div>
      <p className="mt-3 text-center text-[11px] text-white/50">Locked avatars are unlocked with gold. Custom images are cropped square.</p>
    </Modal>
  );
}
