import type { MetadataRoute } from 'next';

export default function manifest(): MetadataRoute.Manifest {
  return {
    name: 'Apex Ascend', short_name: 'Apex', description: 'Defeat bosses. Build your shadow army.',
    start_url: '/', display: 'standalone', orientation: 'portrait', background_color: '#0a0a14', theme_color: '#0a0a14',
    icons: [
      { src: '/pwa-icon/192', sizes: '192x192', type: 'image/png' },
      { src: '/pwa-icon/512', sizes: '512x512', type: 'image/png' },
      { src: '/pwa-icon/512', sizes: '512x512', type: 'image/png', purpose: 'maskable' },
    ],
  };
}
