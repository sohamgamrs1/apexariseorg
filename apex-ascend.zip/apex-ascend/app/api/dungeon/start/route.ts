import { z } from 'zod';
import { callRpc } from '@/lib/rpc';

const Input = z.object({});

export const POST = (req: Request) =>
  callRpc(req, Input, 'start_dungeon', (uid) => ({ p_user: uid }));
